package com.examly.springapp.controller; // Define the package name

import java.util.List; // Import necessary classes

import org.springframework.http.ResponseEntity; // Import ResponseEntity class
import org.springframework.web.bind.annotation.DeleteMapping; // Import DeleteMapping annotation
import org.springframework.web.bind.annotation.GetMapping; // Import GetMapping annotation
import org.springframework.web.bind.annotation.PathVariable; // Import PathVariable annotation
import org.springframework.web.bind.annotation.PostMapping; // Import PostMapping annotation
import org.springframework.web.bind.annotation.RequestBody; // Import RequestBody annotation
import org.springframework.web.bind.annotation.RequestMapping; // Import RequestMapping annotation
import org.springframework.web.bind.annotation.RestController; // Import RestController annotation

import com.examly.springapp.exceptions.UserNotFoundException;
import com.examly.springapp.model.Feedback; // Import Feedback model
import com.examly.springapp.service.FeedbackService; // Import FeedbackService class

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid; // Import Valid annotation
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
@RestController // Mark this class as a RestController
@RequestMapping("/api/feedback") // Define the base URL for feedback-related endpoints
@Tag(name = "Feedback Controller", description = "Controller for managing feedbacks")
public class FeedbackController {

    private final FeedbackService feedbackService; // Inject FeedbackService

    @GetMapping
    @Operation(summary = "Get all feedbacks", description = "Retrieve a list of all feedbacks")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successfully retrieved list",
            content = @Content(mediaType = "application/json",
            schema = @Schema(implementation = Feedback.class))),
        @ApiResponse(responseCode = "500", description = "Internal server error",
            content = @Content)
    })
    public ResponseEntity<List<Feedback>> getAllFeedbacks() {
        // Handle GET request to retrieve all feedbacks and return the response
        log.info("/api/feedback");
        List<Feedback> list = feedbackService.getAllFeedbacks();
        return ResponseEntity.status(200).body(list);
    }

    @PostMapping
    @Operation(summary = "Add new feedback", description = "Add a new feedback to the system")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "201", description = "Feedback added successfully",
            content = @Content(mediaType = "application/json",
            schema = @Schema(implementation = Feedback.class))),
        @ApiResponse(responseCode = "400", description = "Invalid input",
            content = @Content),
        @ApiResponse(responseCode = "500", description = "Internal server error",
            content = @Content)
    })

    public ResponseEntity<Feedback> addFeedback(@Valid @RequestBody Feedback feedback) throws UserNotFoundException {
        // Handle POST request to add a new feedback and return the response
        feedback = feedbackService.addFeedback(feedback);
        return ResponseEntity.status(201).body(feedback);
    }

    @GetMapping("/user/{userId}")
    @Operation(summary = "Get feedbacks by user ID", description = "Retrieve feedbacks for a specific user by their ID")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successfully retrieved feedbacks",
            content = @Content(mediaType = "application/json",
            schema = @Schema(implementation = Feedback.class))),
        @ApiResponse(responseCode = "404", description = "User not found",
            content = @Content),
        @ApiResponse(responseCode = "500", description = "Internal server error",
            content = @Content)
    })
    public ResponseEntity<List<Feedback>> getFeedbackByUserId(@PathVariable int userId) {
        // Handle GET request to retrieve feedbacks by user ID and return the response
        List<Feedback> list = feedbackService.getFeedbackByUserId(userId);
        return ResponseEntity.status(200).body(list);
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete feedback", description = "Delete a feedback by its ID")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Feedback deleted successfully",
            content = @Content(mediaType = "application/json",
            schema = @Schema(implementation = Boolean.class))),
        @ApiResponse(responseCode = "404", description = "Feedback not found",
            content = @Content),
        @ApiResponse(responseCode = "500", description = "Internal server error",
            content = @Content)
    })
    public ResponseEntity<Boolean> deleteFeedback(@PathVariable int id) {
        // Handle DELETE request to delete feedback by ID and return the response
        boolean res = feedbackService.deleteFeedback(id);
        return ResponseEntity.status(200).body(res);
    }
}
