package com.examly.springapp.exceptions; // Define the package name

import java.util.HashMap; // Import necessary classes
import java.util.Map; // Import Map class

import org.springframework.http.ResponseEntity; // Import ResponseEntity class
import org.springframework.web.bind.MethodArgumentNotValidException; // Import MethodArgumentNotValidException class
import org.springframework.web.bind.annotation.ControllerAdvice; // Import ControllerAdvice annotation
import org.springframework.web.bind.annotation.ExceptionHandler; // Import ExceptionHandler annotation

@ControllerAdvice // Mark this class as a global exception handler
public class GlobalExceptionHandler {
    @ExceptionHandler(SeatsNotAvailableException.class) // Handle SeatsNotAvailableException
    public ResponseEntity<String> handleSeatsNotAvailableException(SeatsNotAvailableException e) {
        return ResponseEntity.status(404).body(e.getMessage()); // Return a 204 response with the exception message
    }

    @ExceptionHandler(TripNotFoundException.class) // Handle TripNotFoundException
    public ResponseEntity<String> handleTripNotFoundException(TripNotFoundException e) {
        return ResponseEntity.status(404).body(e.getMessage()); // Return a 204 response with the exception message
    }

    @ExceptionHandler(UserNotFoundException.class) // Handle UserNotFoundException
    public ResponseEntity<String> handleUserNotFoundException(UserNotFoundException e) {
        return ResponseEntity.status(404).body(e.getMessage()); // Return a 204 response with the exception message
    }

    @ExceptionHandler(TripAlreadyExistsException.class) // Handle TripAlreadyExistsException
    public ResponseEntity<String> handleTripAlreadyExistsException(TripAlreadyExistsException e) {
        return ResponseEntity.status(409).body(e.getMessage()); // Return a 409 response with the exception message
    }

    @ExceptionHandler(UserAlreadyExistsException.class) // Handle UserAlreadyExistsException
    public ResponseEntity<String> handleUserAlreadyExistsException(UserAlreadyExistsException e) {
        return ResponseEntity.status(409).body(e.getMessage()); // Return a 409 response with the exception message
    }

    @ExceptionHandler(InsufficientLoyaltyPointsException.class) // Handle InsufficientLoyaltyPointsException
    public ResponseEntity<String> handleInsufficientLoyaltyPointsException(InsufficientLoyaltyPointsException e) {
        return ResponseEntity.status(409).body(e.getMessage()); // Return a 409 response with the exception message
    }

    @ExceptionHandler(LoyaltyNotFoundException.class) // Handle LoyaltyNotFoundException
    public ResponseEntity<String> handleLoyaltyNotFoundException(LoyaltyNotFoundException e) {
        return ResponseEntity.status(404).body(e.getMessage()); // Return a 204 response with the exception message
    }

    @ExceptionHandler(TravellerNotFoundException.class) // Handle TravellerNotFoundException
    public ResponseEntity<String> handleTravellerNotFoundException(TravellerNotFoundException e) {
        return ResponseEntity.status(404).body(e.getMessage()); // Return a 204 response with the exception message
    }

    @ExceptionHandler(MethodArgumentNotValidException.class) // Handle MethodArgumentNotValidException
    public ResponseEntity<String> handleMethodArgumentNotValidException(MethodArgumentNotValidException e) {
        Map<String, String> map = new HashMap<>(); // Create a map to store validation errors
        e.getBindingResult().getFieldErrors().forEach(error -> 
            map.put(error.getField(), error.getDefaultMessage()) // Add each validation error to the map
        );
        return ResponseEntity.status(400).body(map.toString()); // Return a 400 response with the validation errors
    } 
}
