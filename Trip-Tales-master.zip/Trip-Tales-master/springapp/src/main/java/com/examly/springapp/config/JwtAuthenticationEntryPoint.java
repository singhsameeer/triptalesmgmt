/* Define the package name
Import necessary classes
Import AuthenticationException class
Import AuthenticationEntryPoint interface,Import Component annotation,Import ServletException class,Import HttpServletRequest class
*/
package com.examly.springapp.config;
 
import java.io.IOException;
 
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.stereotype.Component;
 
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


/*Import HttpServletResponse class
Send an error response with status code 403 (Forbidden) and message "Unauthorized"*/
@Component
public class JwtAuthenticationEntryPoint implements AuthenticationEntryPoint {
 
    @Override
    public void commence(HttpServletRequest request, HttpServletResponse response,
            AuthenticationException authException) throws IOException, ServletException {
       
        response.sendError(HttpServletResponse.SC_FORBIDDEN, "Unauthorized");
    }
}