package com.examly.springapp.dto; // Define the package name

import lombok.Data; // Import Lombok's Data annotation

@Data // Generate getters, setters, equals, hash, and toString methods
public class UserDTO {
    private String token; // Define token field
    // private String userRole; // Define userRole field
    // private String email; // Define email field
}
