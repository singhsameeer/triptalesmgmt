package com.examly.springapp.controller; // Define the package name

import java.util.List; // Import necessary classes

import org.springframework.http.ResponseEntity; // Import ResponseEntity class
import org.springframework.web.bind.annotation.GetMapping; // Import GetMapping annotation
import org.springframework.web.bind.annotation.PatchMapping; // Import PatchMapping annotation
import org.springframework.web.bind.annotation.PathVariable; // Import PathVariable annotation
import org.springframework.web.bind.annotation.PostMapping; // Import PostMapping annotation
import org.springframework.web.bind.annotation.PutMapping; // Import PutMapping annotation
import org.springframework.web.bind.annotation.RequestBody; // Import RequestBody annotation
import org.springframework.web.bind.annotation.RequestMapping; // Import RequestMapping annotation
import org.springframework.web.bind.annotation.RequestParam; // Import RequestParam annotation
import org.springframework.web.bind.annotation.RestController; // Import RestController annotation

import com.examly.springapp.dto.TravellerApplicationDTO; // Import TravellerApplicationDTo class
import com.examly.springapp.exceptions.LoyaltyNotFoundException;
import com.examly.springapp.exceptions.SeatsNotAvailableException;
import com.examly.springapp.exceptions.TravellerNotFoundException;
import com.examly.springapp.exceptions.TripNotFoundException;
import com.examly.springapp.exceptions.UserNotFoundException;
import com.examly.springapp.model.TravellerApplication; // Import TravellerApplication model
import com.examly.springapp.model.TripDetails; // Import TripDetails model
import com.examly.springapp.service.TravellerService; // Import TravellerService class

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid; // Import Valid annotation
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
@RestController // Mark this class as a RestController
@RequestMapping("/api/traveller") // Define the base URL for traveller-related endpoints
@Tag(name = "Traveller Application Controller", description = "Controller for managing traveller applications")
public class TravellerApplicationController {
  
  private final TravellerService travellerService; // Inject TravellerService

  @PostMapping
  @Operation(summary = "Add a new traveller application", description = "Adds a new traveller application to the system")
  @ApiResponses(value = {
      @ApiResponse(responseCode = "201", description = "Traveller application added successfully",
          content = @Content(mediaType = "application/json",
          schema = @Schema(implementation = TravellerApplication.class))),
      @ApiResponse(responseCode = "400", description = "Invalid input",
          content = @Content),
      @ApiResponse(responseCode = "404", description = "Trip or User not found",
          content = @Content),
      @ApiResponse(responseCode = "500", description = "Internal server error",
          content = @Content)
  })
  public ResponseEntity<TravellerApplication> addTravellerApplication(@Valid @RequestBody TravellerApplicationDTO travellerApplicationDto) 
      throws TripNotFoundException, UserNotFoundException, SeatsNotAvailableException {
    log.info("/api/traveller");
    // Handle POST request to add a new traveller application and return the response
    TravellerApplication travellerApplication = travellerService.addTravellerApplication(travellerApplicationDto);
    return ResponseEntity.status(201).body(travellerApplication);
  }

  @GetMapping("/get/{userId}")
  @Operation(summary = "Get all traveller applications by user ID", description = "Retrieves all traveller applications for a specific user by their ID")
  @ApiResponses(value = {
      @ApiResponse(responseCode = "200", description = "Successfully retrieved traveller applications",
          content = @Content(mediaType = "application/json",
          schema = @Schema(implementation = TravellerApplication.class))),
      @ApiResponse(responseCode = "404", description = "User not found",
          content = @Content),
      @ApiResponse(responseCode = "500", description = "Internal server error",
          content = @Content)
  })
  public ResponseEntity<List<TravellerApplication>> getAllTravellerApplication(@PathVariable int userId) throws UserNotFoundException {
    // Handle GET request to retrieve all traveller applications by user ID and return the response
    return ResponseEntity.status(200).body(travellerService.findTravellerDetailsByUserId(userId));
  }

  @GetMapping("/getall")
  @Operation(summary = "Get all traveller applications", description = "Retrieves all traveller applications")
  @ApiResponses(value = {
      @ApiResponse(responseCode = "200", description = "Successfully retrieved all traveller applications",
          content = @Content(mediaType = "application/json",
          schema = @Schema(implementation = TravellerApplication.class))),
      @ApiResponse(responseCode = "500", description = "Internal server error",
          content = @Content)
  })
  public ResponseEntity<List<TravellerApplication>> getAllTravellerApplications() {
    // Handle GET request to retrieve all traveller applications and return the response
    return ResponseEntity.status(200).body(travellerService.getAllTravellerApplications());
  }

  @GetMapping("/gettraveller/{travellerAppId}")
  @Operation(summary = "Get traveller application by ID", description = "Retrieves a traveller application by its ID")
  @ApiResponses(value = {
      @ApiResponse(responseCode = "200", description = "Successfully retrieved traveller application",
          content = @Content(mediaType = "application/json",
          schema = @Schema(implementation = TravellerApplication.class))),
      @ApiResponse(responseCode = "404", description = "Traveller application not found",
          content = @Content),
      @ApiResponse(responseCode = "500", description = "Internal server error",
          content = @Content)
  })
  public ResponseEntity<TravellerApplication> getByTravellerAppId(@PathVariable int travellerAppId) {
    // Handle GET request to retrieve traveller application by application ID and return the response
    return ResponseEntity.status(200).body(travellerService.findByTravellerAppId(travellerAppId));
  }

  @PatchMapping("/update/{id}")
  @Operation(summary = "Update traveller application", description = "Updates a traveller application by its ID")
  @ApiResponses(value = {
      @ApiResponse(responseCode = "200", description = "Traveller application updated successfully",
          content = @Content(mediaType = "application/json",
          schema = @Schema(implementation = TravellerApplication.class))),
      @ApiResponse(responseCode = "400", description = "Invalid input",
          content = @Content),
      @ApiResponse(responseCode = "404", description = "Traveller application not found",
          content = @Content),
      @ApiResponse(responseCode = "500", description = "Internal server error",
          content = @Content)
  })
  public ResponseEntity<TripDetails> updateTripDetailsByUserId(@Valid @RequestBody TripDetails tripDetails, @PathVariable int id) 
      throws UserNotFoundException, TripNotFoundException {
    // Handle PATCH request to update trip details by user ID and return the response
    return ResponseEntity.status(200).body(travellerService.updateTripDetailsByUserId(tripDetails, id));
  }

  @GetMapping("/filterByStatus")
  @Operation(summary = "Update payment status", description = "Updates the payment status for a specific traveller application")
  @ApiResponses(value = {
      @ApiResponse(responseCode = "200", description = "Payment status updated successfully",
          content = @Content(mediaType = "application/json",
          schema = @Schema(implementation = TravellerApplication.class))),
      @ApiResponse(responseCode = "404", description = "Traveller application not found",
          content = @Content),
      @ApiResponse(responseCode = "500", description = "Internal server error",
          content = @Content)
  })
  public ResponseEntity<List<TravellerApplication>> getByStatus(@RequestParam("paymentStatus") String paymentStatus) {
    // Handle GET request to filter traveller applications by payment status and return the response
    return ResponseEntity.status(200).body(travellerService.findByPaymentStatus(paymentStatus));
  }

  @GetMapping("/{id}/price")
  @Operation(summary = "Get trip price by traveller application ID", description = "Retrieves the trip price for a specific traveller application by its ID")
  @ApiResponses(value = {
      @ApiResponse(responseCode = "200", description = "Successfully retrieved trip price",
          content = @Content(mediaType = "application/json",
          schema = @Schema(implementation = Long.class))),
      @ApiResponse(responseCode = "404", description = "Traveller application not found",
          content = @Content),
      @ApiResponse(responseCode = "500", description = "Internal server error",
          content = @Content)
  })
  public ResponseEntity<Long> getTripPriceByTravellerApplicationId(@PathVariable int id) {
    // Handle GET request to retrieve trip price by traveller application ID and return the response
    return ResponseEntity.status(200).body(travellerService.getTripPriceByTravellerApplicationId(id));
  }

  @PutMapping("{travellerApplicationId}/updateLoyalty/{userId}/seats/{seat}")
  @Operation(summary = "Update loyalty and application status", description = "Updates loyalty points and application status for a specific traveller application")
  @ApiResponses(value = {
      @ApiResponse(responseCode = "200", description = "Loyalty and application status updated successfully",
          content = @Content(mediaType = "application/json",
          schema = @Schema(implementation = String.class))),
      @ApiResponse(responseCode = "404", description = "Traveller application or User not found",
          content = @Content),
      @ApiResponse(responseCode = "500", description = "Internal server error",
          content = @Content)
  })
  public ResponseEntity<TravellerApplication> updateLoyaltyAndApplicationStatus(@PathVariable int travellerApplicationId, @PathVariable int userId,@PathVariable int seat) throws TripNotFoundException, UserNotFoundException, LoyaltyNotFoundException, TravellerNotFoundException, SeatsNotAvailableException{
    // Handle PUT request to update loyalty and application status and return the response
    return ResponseEntity.status(200).body(travellerService.updateLoyaltyAndApplicationStatus(travellerApplicationId, userId, seat));
  }

  @PutMapping("/{id}/status/{status}")
  @Operation(summary = "Update payment status", description = "Updates the payment status for a specific traveller application")
  @ApiResponses(value = {
      @ApiResponse(responseCode = "200", description = "Payment status updated successfully",
          content = @Content(mediaType = "application/json",
          schema = @Schema(implementation = TravellerApplication.class))),
      @ApiResponse(responseCode = "404", description = "Traveller application not found",
          content = @Content),
      @ApiResponse(responseCode = "500", description = "Internal server error",
          content = @Content)
  })
  public ResponseEntity<TravellerApplication> updatePaymentStatus(@PathVariable int id,@PathVariable String status){
    return ResponseEntity.status(200).body(travellerService.updatePaymentStatus(id, status));
  }

}
