package com.examly.springapp.service; // Define the package name

import java.time.LocalDate; // Import necessary classes
import java.util.List; // Import List class
import java.util.Optional; // Import Optional class

import org.springframework.stereotype.Service; // Import Service annotation

import com.examly.springapp.exceptions.UserNotFoundException;
import com.examly.springapp.model.Feedback; // Import Feedback model
import com.examly.springapp.model.User; // Import User model
import com.examly.springapp.repository.FeedbackRepo; // Import Feedback repository
import com.examly.springapp.repository.UserRepo; // Import User repository

import lombok.RequiredArgsConstructor;

@Service // Mark this class as a service
@RequiredArgsConstructor
public class FeedbackServiceImpl implements FeedbackService { // Implement FeedbackService interface

    private final FeedbackRepo feedbackRepo; // Inject Feedback repository

    private final UserRepo userRepo; // Inject User repository

    private static final String USER_NOT_FOUND="User not found!";

    @Override
    public Feedback addFeedback(Feedback feedback) throws UserNotFoundException {
        // Add feedback after checking if the user exists
        Optional<User> user = userRepo.findById(feedback.getUser().getUserId());
        if (user.isEmpty()) {
            throw new UserNotFoundException(USER_NOT_FOUND);
        }
        feedback.setUser(user.get()); // Set user in feedback
        feedback.setDate(LocalDate.now()); // Set current date in feedback
        return feedbackRepo.save(feedback); // Save and return feedback
    }

    @Override
    public List<Feedback> getFeedbackByUserId(int userId) {
        // Get feedbacks by user ID
        return feedbackRepo.getFeedbackByUserId(userId);
    }

    @Override
    public List<Feedback> getAllFeedbacks() {
        // Get all feedbacks
        return feedbackRepo.findAll();
    }

    @Override
    public Optional<Feedback> getFeedbackById(int id) {
        // Get feedback by ID
        return feedbackRepo.findById(id);
    }

    @Override
    public Feedback updateFeedback(int id, Feedback updatedFeedback) {
        // Update feedback if it exists
        Feedback feedback = feedbackRepo.findById(id).orElse(null);
        if (feedback != null) {
            updatedFeedback.setFeedbackId(feedback.getFeedbackId()); // Set feedback ID
            return feedbackRepo.save(updatedFeedback); // Save and return updated feedback
        }
        return null; // Return null if feedback does not exist
    }

    @Override
    public boolean deleteFeedback(int id) {
        // Delete feedback if it exists
        Feedback feedback = feedbackRepo.findById(id).orElse(null);
        if (feedback != null) {
            feedbackRepo.deleteById(id); // Delete feedback by ID
            return true; // Return true if feedback is deleted
        }
        return false; // Return false if feedback does not exist
    }
}
