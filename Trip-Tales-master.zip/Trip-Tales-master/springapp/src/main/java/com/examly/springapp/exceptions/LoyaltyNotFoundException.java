package com.examly.springapp.exceptions;

public class LoyaltyNotFoundException extends Exception {
    public LoyaltyNotFoundException(String msg){
        super(msg);
    }
}
