package com.examly.springapp.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.examly.springapp.model.TravellerApplication;

@Repository
public interface TravellerRepo extends JpaRepository<TravellerApplication,Integer>{

    @Query("select t from TravellerApplication t where t.user.userId=?1")
    List<TravellerApplication> findByUserId(int id);

    List<TravellerApplication> findByPaymentStatus(String paymentStatus);

    @Modifying
    @Query("delete from TravellerApplication t where t.tripDetails.tripId=?1")
    void deleteTravellersByTripId(int tripId);

    @Modifying
    @Query("delete from TravellerApplication t where t.user.userId=?1")
    void deleteTravellersByUserId(int userId);

}
