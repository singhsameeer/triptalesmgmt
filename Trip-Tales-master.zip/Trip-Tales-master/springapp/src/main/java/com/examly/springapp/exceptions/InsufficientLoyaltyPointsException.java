package com.examly.springapp.exceptions;

public class InsufficientLoyaltyPointsException extends Exception{
    public InsufficientLoyaltyPointsException(String msg){
        super(msg);
    }
}
