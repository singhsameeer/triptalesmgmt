package com.examly.springapp.service;

import java.time.LocalDateTime;
import java.util.Optional;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.examly.springapp.config.JwtUtils;
import com.examly.springapp.dto.LoginDTO;
import com.examly.springapp.dto.UserDTO;
import com.examly.springapp.exceptions.UserAlreadyExistsException;
import com.examly.springapp.exceptions.UserNotFoundException;
import com.examly.springapp.model.LoginDetails;
import com.examly.springapp.model.User;
import com.examly.springapp.repository.LoginDetailsRepo;
import com.examly.springapp.repository.UserRepo;

import lombok.RequiredArgsConstructor;


@Service
@RequiredArgsConstructor
public class AuthServiceImpl implements AuthService{

    private final UserRepo userRepo; // Inject User repository

    private final PasswordEncoder encoder; // Inject PasswordEncoder

    private final JwtUtils jwtUtils; // Inject JwtUtils

    private final LoginDetailsRepo loginDetailsRepo;

    private static final String USER_NOT_FOUND="User not found!";
 
    @Override
    public User createUser(User user) throws UserAlreadyExistsException {
        // Create a new user after validation
        Optional<User> existingUser = userRepo.findByEmail(user.getEmail());
        Optional<User> existingUserByMobilenumber = userRepo.findByMobileNumber(user.getMobileNumber());
        Optional<User> existingUserByUsername = userRepo.findByUsername(user.getUsername());
        if (existingUser.isPresent() || existingUserByMobilenumber.isPresent() || existingUserByUsername.isPresent()) {
            throw new UserAlreadyExistsException("User already exists!");
        }
        user.setPassword(encoder.encode(user.getPassword()));
        user = userRepo.save(user);
        return user;
    }
 
    @Override
    public UserDTO loginUser(LoginDTO user) throws UserNotFoundException {
        // Authenticate user and return UserDTO with token
        Optional<User> existingUser = userRepo.findByEmail(user.getEmail());
        if (existingUser.isEmpty()) {
            throw new UserNotFoundException(USER_NOT_FOUND);
        }
        if (encoder.matches(user.getPassword(), existingUser.get().getPassword())) {

            LoginDetails loginDetails=new LoginDetails();
            loginDetails.setEmail(existingUser.get().getEmail());
            loginDetails.setUserRole(existingUser.get().getUserRole());
            loginDetails.setLoginDateTime(LocalDateTime.now());
            loginDetailsRepo.save(loginDetails);

            String token = jwtUtils.createToken(existingUser.get());
            UserDTO userDTO = new UserDTO();
            userDTO.setToken(token);
            return userDTO;
        }
        return null;
    }
}
