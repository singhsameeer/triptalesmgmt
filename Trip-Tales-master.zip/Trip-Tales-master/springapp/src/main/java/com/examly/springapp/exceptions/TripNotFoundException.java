package com.examly.springapp.exceptions;

public class TripNotFoundException extends Exception{
    public TripNotFoundException(String msg){
        super(msg);
    }
}
