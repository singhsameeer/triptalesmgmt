package com.examly.springapp.controller; // Define the package name

import org.springframework.http.ResponseEntity; // Import ResponseEntity class
import org.springframework.web.bind.annotation.GetMapping; // Import GetMapping annotation
import org.springframework.web.bind.annotation.PathVariable; // Import PathVariable annotation
import org.springframework.web.bind.annotation.PostMapping; // Import PostMapping annotation
import org.springframework.web.bind.annotation.PutMapping; // Import PutMapping annotation
import org.springframework.web.bind.annotation.RequestBody; // Import RequestBody annotation
import org.springframework.web.bind.annotation.RequestMapping; // Import RequestMapping annotation
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController; // Import RestController annotation

import com.examly.springapp.dto.LoyaltyDTO;
import com.examly.springapp.exceptions.InsufficientLoyaltyPointsException;
import com.examly.springapp.exceptions.LoyaltyNotFoundException;
import com.examly.springapp.exceptions.UserNotFoundException;
import com.examly.springapp.model.Loyalty; // Import Loyalty model
import com.examly.springapp.service.LoyaltyService; // Import LoyaltyService class

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;


@Slf4j
@RequiredArgsConstructor
@RestController // Mark this class as a RestController
@RequestMapping("/api/loyalty") // Define the base URL for loyalty-related endpoints
@Tag(name = "Loyalty Controller", description = "Controller for managing loyalty points")
public class LoyaltyController {

    private final LoyaltyService loyaltyService; // Inject LoyaltyService

    @GetMapping("/user/{userId}")
     @Operation(summary = "Get loyalty points", description = "Get loyalty points for a specific user")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successfully retrieved all Loyalty points  by user",
            content = @Content(mediaType = "application/json",
            schema = @Schema(implementation = Loyalty.class))),
        @ApiResponse(responseCode = "400", description = "Invalid input",
            content = @Content),
        @ApiResponse(responseCode = "500", description = "Internal server error",
            content = @Content)
    })
    public ResponseEntity<Loyalty> getLoyaltyPointsByUserId(@PathVariable int userId)throws LoyaltyNotFoundException  {
        // Handle GET request to retrieve loyalty points by user ID and return the response
        return ResponseEntity.status(200).body(loyaltyService.getLoyaltyPointsByUserId(userId));
    }

    @PostMapping
    @Operation(summary = "Add loyalty points", description = "Add loyalty points for a specific user")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "201", description = "Loyalty points added successfully",
            content = @Content(mediaType = "application/json",
            schema = @Schema(implementation = Loyalty.class))),
        @ApiResponse(responseCode = "400", description = "Invalid input",
            content = @Content),
        @ApiResponse(responseCode = "500", description = "Internal server error",
            content = @Content)
    })

    public ResponseEntity<Loyalty> addLoyalPoints(@RequestParam("userId") int userId, @RequestBody LoyaltyDTO loyalty) throws UserNotFoundException {
         log.info("/api/loyalty");
        // Handle POST request to add loyalty points and return the response
        return ResponseEntity.status(201).body(loyaltyService.addLoyalty(userId, loyalty));
    }


    @PutMapping
    @Operation(summary = "Update loyalty points", description = "Update loyalty points for a specific user")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Loyalty points updated successfully",
            content = @Content(mediaType = "application/json",
            schema = @Schema(implementation = Loyalty.class))),
        @ApiResponse(responseCode = "400", description = "Invalid input",
            content = @Content),
        @ApiResponse(responseCode = "404", description = "User not found",
            content = @Content),
        @ApiResponse(responseCode = "500", description = "Internal server error",
            content = @Content)
    })
    public ResponseEntity<Loyalty> updateLoyalty(@PathVariable int userId, @RequestBody Loyalty loyalty) throws InsufficientLoyaltyPointsException {
        // Handle PUT request to update loyalty points and return the response
        return ResponseEntity.status(200).body(loyaltyService.updateLoyalty(userId, loyalty));
    }
}
