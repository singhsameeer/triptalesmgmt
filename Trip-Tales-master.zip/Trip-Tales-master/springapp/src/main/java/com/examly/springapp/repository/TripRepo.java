package com.examly.springapp.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.examly.springapp.model.TripDetails;

@Repository
public interface TripRepo extends JpaRepository<TripDetails,Integer>{

    @Query("select t from TripDetails t where t.tripName like %?1%")
    List<TripDetails> findByTripNames(String tripName);

    Optional<TripDetails> findByTripName(String tripName);

    @Query("select t from TripDetails t order by t.tripPrice")
    List<TripDetails> findTripByAcs();

    @Query("select t from TripDetails t order by t.tripPrice desc")
    List<TripDetails> findTripByDsc();

}
