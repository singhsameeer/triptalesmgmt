package com.examly.springapp.service;

import com.examly.springapp.exceptions.UserNotFoundException;
import com.examly.springapp.model.Feedback;
import java.util.List;
import java.util.Optional;

public interface FeedbackService {
    public Feedback addFeedback(Feedback feedback) throws UserNotFoundException;
    public List<Feedback> getFeedbackByUserId(int userId);
    public List<Feedback> getAllFeedbacks();
    public Optional<Feedback> getFeedbackById(int id);
    public Feedback updateFeedback(int id,Feedback updatedFeedback);
    public boolean deleteFeedback(int id);
}
