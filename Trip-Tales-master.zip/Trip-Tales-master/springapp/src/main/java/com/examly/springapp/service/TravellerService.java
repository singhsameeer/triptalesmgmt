package com.examly.springapp.service;

import java.util.List;

import com.examly.springapp.dto.TravellerApplicationDTO;
import com.examly.springapp.exceptions.LoyaltyNotFoundException;
import com.examly.springapp.exceptions.SeatsNotAvailableException;
import com.examly.springapp.exceptions.TravellerNotFoundException;
import com.examly.springapp.exceptions.TripNotFoundException;
import com.examly.springapp.exceptions.UserNotFoundException;
import com.examly.springapp.model.TravellerApplication;
import com.examly.springapp.model.TripDetails;

public interface TravellerService {
   TravellerApplication addTravellerApplication(TravellerApplicationDTO travellerApplicationdto) throws TripNotFoundException, UserNotFoundException , SeatsNotAvailableException;

   TravellerApplication findByTravellerAppId(int id);

   List<TravellerApplication>  findTravellerDetailsByUserId(int userId) throws UserNotFoundException;

   TripDetails updateTripDetailsByUserId(TripDetails tripDetails,int userId) throws UserNotFoundException,TripNotFoundException;

   List<TravellerApplication> getAllTravellerApplications();

   TravellerApplication updatePaymentStatus(int id,String paymentStatus);

   List<TravellerApplication> findByPaymentStatus(String paymentStatus);

   Long getTripPriceByTravellerApplicationId(int travellerApplicationId);

   TravellerApplication updateLoyaltyAndApplicationStatus(int travellerApplicationId,int userId, int seats) throws TripNotFoundException,UserNotFoundException, LoyaltyNotFoundException, TravellerNotFoundException, SeatsNotAvailableException;
   
}
