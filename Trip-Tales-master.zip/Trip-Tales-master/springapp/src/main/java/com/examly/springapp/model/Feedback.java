package com.examly.springapp.model; // Define the package name

import java.time.LocalDate; // Import necessary classes

import jakarta.persistence.Entity; // Import JPA annotations for entity mapping
import jakarta.persistence.GeneratedValue; // Import GeneratedValue annotation
import jakarta.persistence.GenerationType; // Import GenerationType enum
import jakarta.persistence.Id; // Import Id annotation
import jakarta.persistence.JoinColumn; // Import JoinColumn annotation
import jakarta.persistence.ManyToOne; // Import ManyToOne annotation
import jakarta.validation.constraints.NotNull; // Import NotNull validation annotation
import jakarta.validation.constraints.Size; // Import Size validation annotation
import lombok.Data; // Import Lombok's Data annotation

@Data // Generate getters, setters, equals, hash, and toString methods
@Entity // Mark this class as a JPA entity
public class Feedback {
    @Id // Mark this field as the primary key
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Configure the primary key generation strategy
    private int feedbackId; // Define feedback ID

    @NotNull(message = "Feedback text cannot be null") // Ensure feedbackText is not null
    @Size(min = 2, message = "Feedback text should have at least 2 characters") // Ensure feedbackText has at least 2 characters
    private String feedbackText; // Define feedback text
    private LocalDate date; // Define date field

    @NotNull(message = "User id cannot be null") // Ensure user is not null
    @ManyToOne // Define many-to-one relationship with User entity
    @JoinColumn(name="userId") // Specify the foreign key column name
    private User user; // Define user field
}
