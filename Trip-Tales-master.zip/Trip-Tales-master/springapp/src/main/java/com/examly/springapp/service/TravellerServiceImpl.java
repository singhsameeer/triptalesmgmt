package com.examly.springapp.service; // Define the package name

import java.util.ArrayList;
import java.util.List; // Import necessary classes
import java.util.Optional; // Import Optional class

import org.springframework.stereotype.Service; // Import Service annotation

import com.examly.springapp.dto.TravellerApplicationDTO; // Import TravellerApplicationDTo class
import com.examly.springapp.exceptions.LoyaltyNotFoundException;
import com.examly.springapp.exceptions.SeatsNotAvailableException;
import com.examly.springapp.exceptions.TravellerNotFoundException;
import com.examly.springapp.exceptions.TripNotFoundException;
import com.examly.springapp.exceptions.UserNotFoundException;
import com.examly.springapp.model.Loyalty;
import com.examly.springapp.model.TravellerApplication; // Import TravellerApplication model
import com.examly.springapp.model.TripDetails; // Import TripDetails model
import com.examly.springapp.model.User; // Import User model
import com.examly.springapp.repository.LoyaltyRepo;
import com.examly.springapp.repository.TravellerRepo; // Import Traveller repository
import com.examly.springapp.repository.TripRepo; // Import Trip repository
import com.examly.springapp.repository.UserRepo; // Import User repository

import lombok.RequiredArgsConstructor;

@Service // Mark this class as a service
@RequiredArgsConstructor
public class TravellerServiceImpl implements TravellerService { // Implement TravellerService interface

    private final TravellerRepo travellerRepo; // Inject Traveller repository

    private final TripRepo tripRepo; // Inject Trip repository

    private final UserRepo userRepo; // Inject User repository

    private final LoyaltyRepo loyaltyRepo;

    private static final String TRIP_NOT_FOUND="Trip not found";
    private static final String USER_NOT_FOUND="User not found!";

    @Override
    public TravellerApplication addTravellerApplication(TravellerApplicationDTO travellerApplicationdto)
            throws TripNotFoundException, UserNotFoundException, SeatsNotAvailableException {
        // Add a new traveller application after validation
        Optional<TripDetails> tripDetails = tripRepo.findById(travellerApplicationdto.getTripId());
        if (tripDetails.isEmpty()) {
            throw new TripNotFoundException(TRIP_NOT_FOUND);
        }
        Optional<User> user = userRepo.findById(travellerApplicationdto.getUserId());
        if (user.isEmpty()) {
            throw new UserNotFoundException(USER_NOT_FOUND);
        }
        int availableSeats = tripDetails.get().getAvailableSeats();
        if (availableSeats == 0) {
            throw new SeatsNotAvailableException("No seats available");
        }
        TravellerApplication travellerApplication = new TravellerApplication();
        travellerApplication.setUser(user.get());
        travellerApplication.setTripDetails(tripDetails.get());
        travellerApplication.setPaymentStatus("pending");
        return travellerRepo.save(travellerApplication); // Save and return the traveller application
    }

    @Override
    public TravellerApplication findByTravellerAppId(int id) {
        // Find traveller application by ID
        return travellerRepo.findById(id).orElse(null);
    }

    @Override
    public List<TravellerApplication> findTravellerDetailsByUserId(int userId) throws UserNotFoundException {
        // Find traveller applications by user ID
        return travellerRepo.findByUserId(userId);
    }

    @Override
    public TripDetails updateTripDetailsByUserId(TripDetails tripDetails, int userId) throws UserNotFoundException, TripNotFoundException {
        // Update trip details by user ID after validation
        Optional<User> existingUser = userRepo.findById(userId);
        if (existingUser.isEmpty()) {
            throw new UserNotFoundException(USER_NOT_FOUND);
        }
        Optional<TripDetails> existingTripDetails = tripRepo.findById(tripDetails.getTripId());
        if (existingTripDetails.isEmpty()) {
            throw new TripNotFoundException(TRIP_NOT_FOUND);
        }
        return tripRepo.save(tripDetails); // Save and return the updated trip details
    }

    @Override
    public List<TravellerApplication> getAllTravellerApplications() {
        // Get all traveller applications
        return travellerRepo.findAll();
    }

    @Override
    public TravellerApplication updatePaymentStatus(int id, String paymentStatus) {
        // Update payment status of a traveller application
        Optional<TravellerApplication> travellerApplication = travellerRepo.findById(id);
        if (travellerApplication.isEmpty()) {
            return null;
        }
        travellerApplication.get().setPaymentStatus(paymentStatus);
        return travellerRepo.save(travellerApplication.get()); // Save and return the updated traveller application
    }

    @Override
    public List<TravellerApplication> findByPaymentStatus(String paymentStatus) {
        // Find traveller applications by payment status
        return travellerRepo.findByPaymentStatus(paymentStatus);
    }

    @Override
    public Long getTripPriceByTravellerApplicationId(int travellerApplicationId) {
        // Get trip price by traveller application ID
        Optional<TravellerApplication> travellerApplication = travellerRepo.findById(travellerApplicationId);
        if (travellerApplication.isEmpty()) {
            return null;
        }
        return travellerApplication.get().getTripDetails().getTripPrice();
    }

    @Override
    public TravellerApplication updateLoyaltyAndApplicationStatus(int travellerApplicationId, int userId, int seats) throws TripNotFoundException, UserNotFoundException, LoyaltyNotFoundException, TravellerNotFoundException, SeatsNotAvailableException {
        Optional<TravellerApplication> travellerApplication = travellerRepo.findById(travellerApplicationId);
        if (travellerApplication.isEmpty()) {
            throw new TravellerNotFoundException("Traveller not found");
        }
        Optional<TripDetails> tripDetails = tripRepo.findById(travellerApplication.get().getTripDetails().getTripId());
        if (tripDetails.isEmpty()) {
            throw new TripNotFoundException(TRIP_NOT_FOUND);
        }
        if(tripDetails.get().getAvailableSeats()<1){
            throw new SeatsNotAvailableException("Seat not available");
        }
        Optional<User> user = userRepo.findById(userId);
        if (user.isEmpty()) {
            throw new UserNotFoundException(USER_NOT_FOUND);
        }
        Optional<Loyalty> newloyalty=loyaltyRepo.findByUserId(userId);
        if(newloyalty.isEmpty()){
            throw new LoyaltyNotFoundException("Loyalty not found");
        }

        int availableSeats=tripDetails.get().getAvailableSeats();
        int remainingSeats=availableSeats-seats;
        tripDetails.get().setAvailableSeats(remainingSeats);
        tripRepo.save(tripDetails.get());

        
        long newLoyaltyPoints=travellerApplication.get().getTripDetails().getPoints()+newloyalty.get().getLoyaltyPoints();
        newloyalty.get().setLoyaltyPoints(newLoyaltyPoints);
 
        if (newLoyaltyPoints<= 100) {
            newloyalty.get().setLoyaltyLevel(1L);
            List<String> benefits = new ArrayList<>();
            benefits.add("Zero Cancellation Fee");
            newloyalty.get().setBenefits(benefits);
        }
        else if (newLoyaltyPoints> 100 && newLoyaltyPoints<= 300) {
            newloyalty.get().setLoyaltyLevel(2L);
            List<String> benefits = new ArrayList<>();
            benefits.add("Zero Cancellation Fee");
            benefits.add("50% Discount");
            newloyalty.get().setBenefits(benefits);
        }
        else if (newLoyaltyPoints> 300 && newLoyaltyPoints<= 500) {
            newloyalty.get().setLoyaltyLevel(3L);
            List<String> benefits = new ArrayList<>();
            benefits.add("Zero Cancellation Fee");
            benefits.add("50% Discount");
            benefits.add("Premium User");
            newloyalty.get().setBenefits(benefits);
        }
        loyaltyRepo.save(newloyalty.get());

        travellerApplication.get().setPaymentStatus("success");
        return travellerRepo.save(travellerApplication.get()); 
    }
}
