package com.examly.springapp.service;

import java.util.List;

import com.examly.springapp.exceptions.TripAlreadyExistsException;
import com.examly.springapp.exceptions.TripNotFoundException;
import com.examly.springapp.model.TripDetails;

public interface TripService {

    TripDetails addTrip(TripDetails tripDetails) throws TripAlreadyExistsException;
    TripDetails findTripDetails(int tripId)throws TripNotFoundException;
    List<TripDetails> findallTripDetails();
    TripDetails updateTripDetails(TripDetails tripDetails, int id)throws TripNotFoundException,TripAlreadyExistsException;
    boolean deleteTrip(int tripId)throws TripNotFoundException;
    int findRemainingSeats(int tripId) throws TripNotFoundException;
    List<TripDetails> getTripsSortedByPrice(String order);
    List<TripDetails> getTripsByName(String tripName);
}
