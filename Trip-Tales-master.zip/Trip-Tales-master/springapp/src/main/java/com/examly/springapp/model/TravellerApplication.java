package com.examly.springapp.model; // Define the package name

import jakarta.persistence.Entity; // Import necessary classes for JPA entity mapping
import jakarta.persistence.GeneratedValue; // Import GeneratedValue annotation
import jakarta.persistence.GenerationType; // Import GenerationType enum
import jakarta.persistence.Id; // Import Id annotation
import jakarta.persistence.JoinColumn; // Import JoinColumn annotation
import jakarta.persistence.ManyToOne; // Import ManyToOne annotation
import jakarta.validation.constraints.NotNull; // Import NotNull validation annotation
import jakarta.validation.constraints.Pattern; // Import Pattern validation annotation
import lombok.Data; // Import Lombok's Data annotation

@Data // Generate getters, setters, equals, hash, and toString methods
@Entity // Mark this class as a JPA entity
public class TravellerApplication {
  @Id // Mark this field as the primary key
  @GeneratedValue(strategy = GenerationType.IDENTITY) // Configure the primary key generation strategy
  private int id; // Define ID field

  @NotNull(message = "User id cannot be null") // Ensure user is not null
  @ManyToOne // Define many-to-one relationship with User entity
  @JoinColumn(name = "userId") // Specify the foreign key column name
  private User user; // Define user field

  @NotNull(message = "Trip id cannot be null") // Ensure tripDetails is not null
  @ManyToOne // Define many-to-one relationship with TripDetails entity
  @JoinColumn(name = "tripId") // Specify the foreign key column name
  private TripDetails tripDetails; // Define trip details field

  @NotNull(message = "Payment status cannot be null") // Ensure paymentStatus is not null
  @Pattern(regexp = "approved|denied|pending|success", message = "Payment status must be either success, approved, failed, or pending") // Validate paymentStatus with specified pattern
  private String paymentStatus; // Define payment status field
}
