package com.examly.springapp.exceptions;

public class TravellerNotFoundException extends Exception{
    public TravellerNotFoundException(String msg){
        super(msg);
    }
}
