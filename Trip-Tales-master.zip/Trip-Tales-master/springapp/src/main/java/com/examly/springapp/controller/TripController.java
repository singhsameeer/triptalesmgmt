package com.examly.springapp.controller; // Define the package name

import java.util.List; // Import necessary classes

import org.springframework.http.ResponseEntity; // Import ResponseEntity class
import org.springframework.web.bind.annotation.DeleteMapping; // Import DeleteMapping annotation
import org.springframework.web.bind.annotation.GetMapping; // Import GetMapping annotation
import org.springframework.web.bind.annotation.PathVariable; // Import PathVariable annotation
import org.springframework.web.bind.annotation.PostMapping; // Import PostMapping annotation
import org.springframework.web.bind.annotation.PutMapping; // Import PutMapping annotation
import org.springframework.web.bind.annotation.RequestBody; // Import RequestBody annotation
import org.springframework.web.bind.annotation.RequestMapping; // Import RequestMapping annotation
import org.springframework.web.bind.annotation.RequestParam; // Import RequestParam annotation
import org.springframework.web.bind.annotation.RestController; // Import RestController annotation

import com.examly.springapp.exceptions.TripAlreadyExistsException;
import com.examly.springapp.exceptions.TripNotFoundException;
import com.examly.springapp.model.TripDetails; // Import TripDetails model
import com.examly.springapp.service.TripService; // Import TripService class

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid; // Import Valid annotation
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
@RestController // Mark this class as a RestController
@RequestMapping("/api/trip") // Define the base URL for trip-related endpoints
@Tag(name = "Trip Controller", description = "Controller for managing trips")
public class TripController {
    
    private final TripService tripService; // Inject TripService

    @PostMapping
    @Operation(summary = "Add a new trip", description = "Adds a new trip to the system")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "201", description = "Trip added successfully",
            content = @Content(mediaType = "application/json",
            schema = @Schema(implementation = TripDetails.class))),
        @ApiResponse(responseCode = "400", description = "Invalid input",
            content = @Content),
        @ApiResponse(responseCode = "500", description = "Internal server error",
            content = @Content)
    })
    public ResponseEntity<TripDetails> addTrip(@Valid @RequestBody TripDetails tripDetails) throws TripAlreadyExistsException {
        log.info("/api/trip");
        // Handle POST request to add a new trip and return the response
        tripDetails = tripService.addTrip(tripDetails);
        return ResponseEntity.status(201).body(tripDetails);
    }

    @GetMapping("/getall")
    @Operation(summary = "Get all trips", description = "Retrieves all trips")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successfully retrieved all trips",
            content = @Content(mediaType = "application/json",
            schema = @Schema(implementation = TripDetails.class))),
        @ApiResponse(responseCode = "500", description = "Internal server error",
            content = @Content)
    })
    public ResponseEntity<List<TripDetails>> getAllTrips() {
        // Handle GET request to retrieve all trips and return the response
        List<TripDetails> list = tripService.findallTripDetails();
        return ResponseEntity.status(200).body(list);
    }

    @PutMapping("/update/{id}")
    @Operation(summary = "Update a trip", description = "Updates a trip by its ID")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Trip updated successfully",
            content = @Content(mediaType = "application/json",
            schema = @Schema(implementation = TripDetails.class))),
        @ApiResponse(responseCode = "400", description = "Invalid input",
            content = @Content),
        @ApiResponse(responseCode = "404", description = "Trip not found",
            content = @Content),
        @ApiResponse(responseCode = "500", description = "Internal server error",
            content = @Content)
    })
    public ResponseEntity<TripDetails> updateTrip(@PathVariable int id, @Valid @RequestBody TripDetails tripDetails) throws TripNotFoundException, TripAlreadyExistsException {
        // Handle PUT request to update a trip by ID and return the response
        tripDetails = tripService.updateTripDetails(tripDetails, id);
        return ResponseEntity.status(200).body(tripDetails);
    }

    @DeleteMapping("/delete")
    @Operation(summary = "Delete a trip", description = "Deletes a trip by its ID")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Trip deleted successfully",
            content = @Content(mediaType = "application/json",
            schema = @Schema(implementation = Boolean.class))),
        @ApiResponse(responseCode = "404", description = "Trip not found",
            content = @Content),
        @ApiResponse(responseCode = "500", description = "Internal server error",
            content = @Content)
    })
    public ResponseEntity<Boolean> deleteTrip(@RequestParam("tripId") int tripId) throws TripNotFoundException {
        // Handle DELETE request to delete a trip by ID and return the response
        boolean isDeleted = tripService.deleteTrip(tripId);
        return ResponseEntity.status(isDeleted ? 200 : 500).body(isDeleted);
    }

    @GetMapping("/get")
    @Operation(summary = "Get a trip by ID", description = "Retrieves a trip by its ID")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successfully retrieved trip",
            content = @Content(mediaType = "application/json",
            schema = @Schema(implementation = TripDetails.class))),
        @ApiResponse(responseCode = "404", description = "Trip not found",
            content = @Content),
        @ApiResponse(responseCode = "500", description = "Internal server error",
            content = @Content)
    })
    public ResponseEntity<TripDetails> getTripById(@RequestParam("tripId") int tripId) throws TripNotFoundException {
        // Handle GET request to retrieve a trip by ID and return the response
        TripDetails tripDetails = tripService.findTripDetails(tripId);
        return ResponseEntity.status(200).body(tripDetails);
    }

    @GetMapping("/sortedByPrice")
    @Operation(summary = "Get trips sorted by price", description = "Retrieves trips sorted by price")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successfully retrieved sorted trips",
            content = @Content(mediaType = "application/json",
            schema = @Schema(implementation = TripDetails.class))),
        @ApiResponse(responseCode = "500", description = "Internal server error",
            content = @Content)
    })
    public ResponseEntity<List<TripDetails>> getTripByPrice(@RequestParam("order") String order) {
        // Handle GET request to retrieve trips sorted by price and return the response
        List<TripDetails> list = tripService.getTripsSortedByPrice(order);
        return ResponseEntity.status(200).body(list);
    }

    @GetMapping("/searchByName")
    @Operation(summary = "Search trips by name", description = "Searches for trips by name")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successfully retrieved trips",
            content = @Content(mediaType = "application/json",
            schema = @Schema(implementation = TripDetails.class))),
        @ApiResponse(responseCode = "500", description = "Internal server error",
            content = @Content)
    })
    public ResponseEntity<List<TripDetails>> getTripSearchByName(@RequestParam("tripName") String tripName) {
        // Handle GET request to search trips by name and return the response
        List<TripDetails> list = tripService.getTripsByName(tripName);
        return ResponseEntity.status(200).body(list);
    }
}
