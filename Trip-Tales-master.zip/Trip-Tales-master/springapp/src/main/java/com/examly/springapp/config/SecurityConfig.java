package com.examly.springapp.config;

import java.util.Arrays;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import lombok.RequiredArgsConstructor;


@Configuration
@EnableWebMvc
@EnableWebSecurity
@EnableMethodSecurity
@RequiredArgsConstructor
public class SecurityConfig {

    /*
     * Inject JwtAuthenticationEntryPoint
     * Inject JwtAuthenticationFilter
     * Inject PasswordEncoder
     * Inject UserDetailsService
     */
    private final JwtAuthenticationEntryPoint authEntryPoint;
 
    private final JwtAuthenticationFilter authFilter;


    private static final String ADMIN = "Admin";
    private static final String USER = "User";
    private static final String USER_API_END_POINT = "/api/user/{userId}";

    /*
     * Set allowed origins for CORS
     * Specify allowed methods
     * Specify allowed headers
     * Allow credentials
     * Register CORS configuration for all paths
     */
    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration configuration = new CorsConfiguration();

        configuration.setAllowedOrigins(
                Arrays.asList("https://8081-aaaeecbfedddeecbcafaabbcfbccafe.premiumproject.examly.io/",
                "https://8081-cddadfbefedddeecbcafaabbcfbccafe.premiumproject.examly.io/",
                "https://8081-cbccfbaadfedddeecbcafaabbcfbccafe.premiumproject.examly.io/",
                "https://8081-ddcfebdccabfedddeecbcafaabbcfbccafe.premiumproject.examly.io/",
                "https://8081-ccaaabeccffedddeecbcafaabbcfbccafe.premiumproject.examly.io/",
                "https://8081-cddbfbfefcfdeefedddeecbcafaabbcfbccafe.premiumproject.examly.io/"));
        configuration.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "DELETE")); // Specify allowed methods
        configuration.setAllowedHeaders(Arrays.asList("Authorization", "Content-Type")); // Specify allowed headers
        configuration.setAllowCredentials(true);
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", configuration);
        return source;
    }

    /*
     * Enable CORS with specified configuration
     * Disable CSRF protection
     * Allow access to Swagger documentation
     * Allow access to login and register endpoints
     * Restrict access to specific roles
     * Handle authentication entry point
     * Add JWT authentication filter
     */

    @Bean
    public SecurityFilterChain createSecurityFilterChain(HttpSecurity http) throws Exception {
        http.cors().configurationSource(corsConfigurationSource())
                .and()
                .csrf(csrf -> csrf.disable())
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers(HttpMethod.POST, "/api/trip").hasRole(ADMIN)
                        .requestMatchers(HttpMethod.PUT, "/api/trip/update/{id}").hasRole(ADMIN)
                        .requestMatchers(HttpMethod.GET,
                                "/api/trip/getall",
                                "/api/trip/get",
                                "/api/trip/sortedByPrice",
                                "/api/trip/searchByName",
                                "/api/trip/{userId}")
                        .hasAnyRole(ADMIN, USER)
                        .requestMatchers(HttpMethod.PUT, USER_API_END_POINT).hasRole(ADMIN)
                        .requestMatchers(HttpMethod.GET,
                                "/api/user",
                                USER_API_END_POINT)
                        .hasRole(ADMIN)
                        .requestMatchers(HttpMethod.GET, "/api/user/userEmail/{email}").hasAnyRole(ADMIN, USER)
                        .requestMatchers(HttpMethod.DELETE, "/api/user/deleteUser/{userId}").hasRole(ADMIN)
                        .requestMatchers(HttpMethod.POST, "/api/feedback").hasRole(USER)
                        .requestMatchers(HttpMethod.GET,
                                "/api/feedback",
                                "/api/feedback/user/{userId}")
                        .hasAnyRole(ADMIN, USER)
                        .requestMatchers(HttpMethod.DELETE, "/api/feedback/{id}").hasRole(USER)
                        .requestMatchers(HttpMethod.POST, "/api/traveller").hasRole(USER)
                        .requestMatchers(HttpMethod.PATCH, "/api/traveller/update/{id}").hasAnyRole(ADMIN, USER)
                        .requestMatchers(HttpMethod.GET,
                                "/api/traveller/get/{userId}",
                                "/api/traveller/getall",
                                "/api/traveller/gettraveller/{travellerAppId}",
                                "/api/traveller/filterByStatus",
                                "/api/traveller/{id}/price",
                                "/api/traveller/{id}/status/{status}")
                        .hasAnyRole(ADMIN, USER)
                        .requestMatchers(HttpMethod.PUT, "/api/traveller/{travellerApplicationId}/updateLoyalty/{userId}/seats/{seat}").hasRole(USER)
                        .requestMatchers(HttpMethod.POST, "/api/loyalty").hasAnyRole(ADMIN, USER)
                        .requestMatchers(HttpMethod.GET, "/api/loyalty/user/{userId}").hasAnyRole(ADMIN, USER)
                        .anyRequest().permitAll())
                .exceptionHandling(exceptionHandling -> exceptionHandling.authenticationEntryPoint(authEntryPoint))
                .addFilterBefore(authFilter, UsernamePasswordAuthenticationFilter.class);
        return http.build();
    }
}