package com.examly.springapp.service;


import java.util.List;

import com.examly.springapp.exceptions.UserNotFoundException;
import com.examly.springapp.model.User;

public interface UserService {
    
    User updateUser(int userId,User user)throws UserNotFoundException;
    
    void deleteUser(int userId)throws UserNotFoundException;
    
    User findUserById(int userId)throws UserNotFoundException;

    User getUserByEmail(String email)throws UserNotFoundException;

    List<User> getAllUsers();

}
