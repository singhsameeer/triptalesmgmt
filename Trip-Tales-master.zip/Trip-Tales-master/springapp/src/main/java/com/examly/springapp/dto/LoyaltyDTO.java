package com.examly.springapp.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class LoyaltyDTO {
    @NotNull(message = "Loyalty Points cannot be null")
    @Min(value=0, message="Loyalty Points can not be less than 0")
    private Long loyaltyPoints;
}
