/*Define the package name,Import necessary classes,Import List class,Import GrantedAuthority interface
Import UserDetails interface,Import User model*/
package com.examly.springapp.config;
 
import java.util.Collection;
import java.util.List;
 
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
 
import com.examly.springapp.model.User;
 
/*Implement UserDetails interface,Constructor to initialize UserPrinciple with User object,Define a User object,
Return a list of GrantedAuthority objects based on the user's role,Return the user's password,Return the user's email as the username
Indicate that the account is not expired,Indicate that the account is not locked, Indicate that the credentials are not expired
Indicate that the account is enabled*/
public class UserPrinciple implements UserDetails {
 
    private final transient User user;
 
    public UserPrinciple(User user) {
        this.user = user;
    }
 
    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return List.of(() -> "ROLE_" + user.getUserRole());
    }
 
    @Override
    public String getPassword() {
       
        return user.getPassword();
    }
 
    @Override
    public String getUsername() {
        return user.getEmail();
    }
 
    @Override
    public boolean isAccountNonExpired() {
        return true;
    }
 
    @Override
    public boolean isAccountNonLocked() {
        return true;
    }
 
    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }
 
    @Override
    public boolean isEnabled() {
        return true;
    }
 
}