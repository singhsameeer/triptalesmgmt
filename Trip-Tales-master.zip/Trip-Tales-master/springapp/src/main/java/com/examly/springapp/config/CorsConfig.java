package com.examly.springapp.config; // Define the package name

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;

import lombok.RequiredArgsConstructor;
 
 
 
/*Mark this class as a configuration class
Enable Spring MVC
Enable Spring Security
Enable method-level security*/
@Configuration
@RequiredArgsConstructor
public class CorsConfig {
 
/*Inject JwtAuthenticationEntryPoint
Inject JwtAuthenticationFilter
Inject PasswordEncoder
Inject UserDetailsService*/
    
    private final PasswordEncoder encoder;
 
    private final UserDetailsService userService;

 
    /*  Set user details service
     Set password encoder
     Build and return the AuthenticationManager*/
    @Bean
    public AuthenticationManager createAuthenticationManager(HttpSecurity http) throws Exception {
        return http.getSharedObject(AuthenticationManagerBuilder.class)
            .userDetailsService(userService)
            .passwordEncoder(encoder)
            .and()
            .build();
    }
    /*Configure AuthenticationManagerBuilder
    Set password encoder*/
    public final void configure(AuthenticationManagerBuilder builder) throws Exception {
        builder.userDetailsService(userService)
            .passwordEncoder(encoder);
    }
}