import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { RegistrationComponent } from './components/registration/registration.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { AdminnavComponent } from './components/adminnav/adminnav.component';
import { UsernavComponent } from './components/usernav/usernav.component';
import { HomeComponent } from './components/home/home.component';
import { CreatetripComponent } from './components/createtrip/createtrip.component';
import { AdminviewtripComponent } from './components/adminviewtrip/adminviewtrip.component';
import { AdminviewfeedbackComponent } from './components/adminviewfeedback/adminviewfeedback.component';
import { ViewtripComponent } from './components/viewtrip/viewtrip.component';
import { PaymentComponent } from './components/payment/payment.component';
import { UseraddfeedbackComponent } from './components/useraddfeedback/useraddfeedback.component';
import { ConfirmBookingComponent } from './components/confirm-booking/confirm-booking.component';
import { EdittripComponent } from './components/edittrip/edittrip.component';
import { UserviewfeedbackComponent } from './components/userviewfeedback/userviewfeedback.component';
import { UserTravellerApplicationsComponent } from './components/user-traveller-applications/user-traveller-applications.component';
import { AdminTravellerApplicationsComponent } from './components/admin-traveller-applications/admin-traveller-applications.component';
import { ClaimLoyaltyComponent } from './components/claim-loyalty/claim-loyalty.component';
import { UserProfileComponent } from './components/user-profile/user-profile.component';
import { UserGuard } from './guards/user.guard';
import { AdminGuard } from './guards/admin.guard';
import { ErrorComponent } from './components/error/error.component';
import { AdminDashboardComponent } from './components/admin-dashboard/admin-dashboard.component';


const routes: Routes = [
  {path:'',component:HomeComponent},
  {path:'login',component:LoginComponent},
  {path:'register',component:RegistrationComponent},
  {path:'navbar',component:NavbarComponent},
  {path:'adminnav',component:AdminnavComponent, canActivate:[AdminGuard]},
  {path:'usernav',component:UsernavComponent, canActivate:[UserGuard]},
  {path:'add-trip',component:CreatetripComponent, canActivate:[AdminGuard]},
  {path:'adminview-trip',component:AdminviewtripComponent, canActivate:[AdminGuard]},
  {path:'admin-traveller-application',component:AdminTravellerApplicationsComponent, canActivate:[AdminGuard]},
  {path:'adminfeedback',component:AdminviewfeedbackComponent, canActivate:[AdminGuard]},
  {path:'userview-trip',component:ViewtripComponent, canActivate:[UserGuard]},
  {path:'user-payment/:id',component:PaymentComponent, canActivate:[UserGuard]},
  {path:'useradd-feedback',component:UseraddfeedbackComponent, canActivate:[UserGuard]},
  {path:'confirm-booking/:id',component:ConfirmBookingComponent, canActivate:[UserGuard]},
  {path:'edit-trip/:id',component:EdittripComponent, canActivate:[AdminGuard]},
  {path:'userview-feedback',component:UserviewfeedbackComponent, canActivate:[UserGuard]},
  {path:'user-traveller-application',component:UserTravellerApplicationsComponent, canActivate:[UserGuard]},
  {path:'claim-loyalty',component:ClaimLoyaltyComponent, canActivate:[UserGuard]},
  {path:'user-profile',component:UserProfileComponent},
  {path:'admin-dashboard',component:AdminDashboardComponent, canActivate:[AdminGuard]},
  {path:'**',component:ErrorComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
