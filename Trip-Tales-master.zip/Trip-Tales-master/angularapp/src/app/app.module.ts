import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AdminTravellerApplicationsComponent } from './components/admin-traveller-applications/admin-traveller-applications.component';
import { AdminnavComponent } from './components/adminnav/adminnav.component';
import { AdminviewfeedbackComponent } from './components/adminviewfeedback/adminviewfeedback.component';
import { AdminviewtripComponent } from './components/adminviewtrip/adminviewtrip.component';
import { ClaimLoyaltyComponent } from './components/claim-loyalty/claim-loyalty.component';
import { CreatetripComponent } from './components/createtrip/createtrip.component';
import { EdittripComponent } from './components/edittrip/edittrip.component';
import { ErrorComponent } from './components/error/error.component';
import { HomeComponent } from './components/home/home.component';
import { LoginComponent } from './components/login/login.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { PaymentComponent } from './components/payment/payment.component';
import { RegistrationComponent } from './components/registration/registration.component';
import { TravellerApplicationComponent } from './components/traveller-application/traveller-application.component';
import { UserTravellerApplicationsComponent } from './components/user-traveller-applications/user-traveller-applications.component';
import { UseraddfeedbackComponent } from './components/useraddfeedback/useraddfeedback.component';
import { UsernavComponent } from './components/usernav/usernav.component';
import { UserviewfeedbackComponent } from './components/userviewfeedback/userviewfeedback.component';
import { ViewtripComponent } from './components/viewtrip/viewtrip.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { AuthInterceptor } from './interceptors/auth.interceptor';
import { RequestedTripComponent } from './components/requested-trip/requested-trip.component';
import { ConfirmBookingComponent } from './components/confirm-booking/confirm-booking.component';
import { UserProfileComponent } from './components/user-profile/user-profile.component';
import { LoadingComponent } from './components/loading/loading.component';
import { LoadingInterceptor } from './interceptors/loading.interceptor';
import { AdminDashboardComponent } from './components/admin-dashboard/admin-dashboard.component';


@NgModule({
  declarations: [
    AppComponent,
    AdminTravellerApplicationsComponent,
    AdminnavComponent,
    AdminviewfeedbackComponent,
    AdminviewtripComponent,
    ClaimLoyaltyComponent,
    CreatetripComponent,
    EdittripComponent,
    ErrorComponent,
    HomeComponent,
    LoginComponent,
    NavbarComponent,
    PaymentComponent,
    RegistrationComponent,
    TravellerApplicationComponent,
    UserTravellerApplicationsComponent, 
    UseraddfeedbackComponent,
    UsernavComponent,
    UserviewfeedbackComponent,
    ViewtripComponent,
    RequestedTripComponent,
    ConfirmBookingComponent,
    UserProfileComponent,
    LoadingComponent,
    AdminDashboardComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: LoadingInterceptor, multi: true }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
