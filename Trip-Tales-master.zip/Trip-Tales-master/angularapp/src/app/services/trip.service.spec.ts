
import { TestBed } from '@angular/core/testing';

import { TripService } from './trip.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('TripService', () => {
  let service: TripService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
    });
    service = TestBed.inject(TripService);
  });

  fit('Frontend_should_create_trip_service', () => {
    expect(service).toBeTruthy();
  });
});
