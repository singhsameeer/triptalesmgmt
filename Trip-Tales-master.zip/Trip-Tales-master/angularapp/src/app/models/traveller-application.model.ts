import { TripDetails } from "./trip-details.model"
import { User } from "./user.model"

// Interface definition for TravellerApplication
export interface TravellerApplication {
    // Optional property for application ID
    id?: number;
    // Property for user details (reference to User model)
    user?: User;
    // Property for trip details (reference to TripDetails model)
    tripDetails?: TripDetails;
    // Property for application status
    paymentStatus?: string;

    userId?:number;
    tripId?:number;
}
