// Interface definition for User
export interface User {
    // Optional property for user ID
    userId?: number;
    // Property for user's email address
    email: string;
    // Property for user's password
    password: string;
    // Property for user's username
    username: string;
    // Property for user's mobile number
    mobileNumber: string;
    // Property for user's role (e.g., Admin, User)
    userRole: string;
}
