import { User } from "./user.model";

// Interface definition for Loyalty
export interface Loyalty {
    // Optional property for loyalty ID
    id?: number;
    // Optional property for user details (reference to User model)
    user?: User;
    // Property for loyalty points
    loyaltyPoints: number;
    // Property for loyalty level
    loyaltyLevel?: number;
    // Property for loyalty benefits (array of strings)
    benefits?: string[];

    claimedInitialPoints?:boolean
}
