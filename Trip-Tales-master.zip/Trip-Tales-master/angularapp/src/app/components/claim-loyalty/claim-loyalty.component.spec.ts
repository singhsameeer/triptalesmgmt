import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClaimLoyaltyComponent } from './claim-loyalty.component';

describe('ClaimLoyaltyComponent', () => {
  let component: ClaimLoyaltyComponent;
  let fixture: ComponentFixture<ClaimLoyaltyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClaimLoyaltyComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClaimLoyaltyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
