import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TravellerApplication } from 'src/app/models/traveller-application.model';
import { TripDetails } from 'src/app/models/trip-details.model';
import { User } from 'src/app/models/user.model';
import { AuthService } from 'src/app/services/auth.service';
import { TravellerService } from 'src/app/services/traveller.service';
import { TripService } from 'src/app/services/trip.service';

@Component({
  selector: 'app-confirm-booking',
  templateUrl: './confirm-booking.component.html',
  styleUrls: ['./confirm-booking.component.css']
})
export class ConfirmBookingComponent implements OnInit {
  trip:TripDetails={
    tripId:0,
    tripName: '',
    tripDuration: 0,
    tripPrice: 0,
    tripStartLocation: '',
    tripLocations: [],
    date: '',
    totalSeats: 0,
    availableSeats: 0,
    points: 0
  }

  user: User = {
    userId: 0,
    email: '',
    password: '',
    username: '',
    mobileNumber: '',
    userRole: ''
  }

  traveller:TravellerApplication={
    user: this.user,
    tripDetails: this.trip,
    userId:0,
    tripId:0
  }

  useremail: string = '';

  showSuccessModal: boolean = false;
  showFailureModal: boolean = false;

  constructor(private readonly authService:AuthService, private readonly tripService:TripService,private readonly travellerService:TravellerService,private readonly activatedRoute:ActivatedRoute,private readonly router:Router) { }

  ngOnInit(): void {
    this.useremail = this.authService.getUseremail();
    this.authService.getUserByEmail(this.useremail).subscribe(
      (res) => {
        this.user = res;
        this.updateTraveller();
      },
      (error) => {
        console.error('Error fetching user by email:', error);
      }
    );

    const id = +this.activatedRoute.snapshot.paramMap.get('id');
    this.tripService.findTripById(id).subscribe((res) => {
      this.trip = res;
      this.updateTraveller();
    });
}

  updateTraveller() {
    if (this.user.userId && this.trip.tripId) {
        this.traveller = {
            userId: this.user.userId,
            tripId: this.trip.tripId,
        };
    }
  }


  confirmBooking() {
    if (this.trip.tripId != null && this.user.userId != null) {
      this.travellerService.addTravellerApplication(this.traveller).subscribe(
        () => {
          this.showSuccessModal = true;
          setTimeout(() => {
            this.router.navigate(['/user-traveller-application']);
          }, 2000);
        },
        (error) => {
          console.error('Error adding traveller application:', error);
          this.showFailureModal = true;
        }
      );
    }
  }
  
  closeModals() {
    this.showSuccessModal = false;
    this.showFailureModal = false;
  }
  
  navigateToTrips() {
    this.router.navigate(['/user-traveller-application']);
  }

}
