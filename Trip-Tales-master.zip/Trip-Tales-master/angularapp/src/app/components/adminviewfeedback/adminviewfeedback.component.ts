import { Component, OnInit } from '@angular/core';
import { Feedback } from 'src/app/models/feedback.model';
import { User } from 'src/app/models/user.model';
import { FeedbackService } from 'src/app/services/feedback.service';

@Component({
  selector: 'app-adminviewfeedback',
  templateUrl: './adminviewfeedback.component.html',
  styleUrls: ['./adminviewfeedback.component.css']
})
export class AdminviewfeedbackComponent implements OnInit {
  feedbacks: Feedback[] = [];
  paginatedFeedbacks: Feedback[] = []; // Paginated list
  useremail: string = '';
  showConfirmDelete: boolean = false;
  feedbackToDelete: number = null;

  user: User = {
    userId: 0,
    email: '',
    password: '',
    username: '',
    mobileNumber: '',
    userRole: ''
  };

  // Pagination properties
  currentPage: number = 1;
  itemsPerPage: number = 8; // 8 items per page
  totalPages: number = 0;

  constructor(private readonly feedbackService: FeedbackService) {}

  ngOnInit(): void {
    this.getFeedbacks();
  }

  getFeedbacks() {
    this.feedbackService.getFeedbacks().subscribe((res) => {
      this.feedbacks = res;
      this.updatePagination(); // Update pagination after loading data
    });
  }

  updatePagination() {
    this.totalPages = Math.ceil(this.feedbacks.length / this.itemsPerPage);
    this.paginate();
  }

  paginate() {
    const startIndex = (this.currentPage - 1) * this.itemsPerPage;
    const endIndex = startIndex + this.itemsPerPage;
    this.paginatedFeedbacks = this.feedbacks.slice(startIndex, endIndex);
  }

  goToPage(page: number) {
    if (page >= 1 && page <= this.totalPages) {
      this.currentPage = page;
      this.paginate();
    }
  }

  previousPage() {
    if (this.currentPage > 1) {
      this.currentPage--;
      this.paginate();
    }
  }

  nextPage() {
    if (this.currentPage < this.totalPages) {
      this.currentPage++;
      this.paginate();
    }
  }

  getPages(): number[] {
    const pages: number[] = [];
    for (let i = 1; i <= this.totalPages; i++) {
      pages.push(i);
    }
    return pages;
  }

  showUser(userDetails: User) {
    this.user = userDetails;
  }

  closeModal() {
    this.user = {
      userId: 0,
      email: '',
      password: '',
      username: '',
      mobileNumber: '',
      userRole: ''
    };
  }
}