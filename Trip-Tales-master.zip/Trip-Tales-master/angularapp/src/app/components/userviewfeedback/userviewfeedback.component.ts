import { Component, OnInit } from '@angular/core';
import { Feedback } from 'src/app/models/feedback.model';
import { User } from 'src/app/models/user.model';
import { AuthService } from 'src/app/services/auth.service';
import { FeedbackService } from 'src/app/services/feedback.service';

@Component({
  selector: 'app-userviewfeedback',
  templateUrl: './userviewfeedback.component.html',
  styleUrls: ['./userviewfeedback.component.css']
})
export class UserviewfeedbackComponent implements OnInit {
  feedbacks: Feedback[] = [];
  paginatedFeedbacks: Feedback[] = []; // Paginated list
  user: User = {
    userId: 0,
    email: '',
    password: '',
    username: '',
    mobileNumber: '',
    userRole: ''
  };
  useremail: string = '';
  showConfirmDelete: boolean = false;
  feedbackToDelete: number = null;
  showSuccessModal: boolean = false;
  showFailureModal: boolean = false;

  // Pagination properties
  currentPage: number = 1;
  itemsPerPage: number = 8; // 8 items per page
  totalPages: number = 0;

  constructor(private readonly authService: AuthService, private readonly feedbackService: FeedbackService) {}

  ngOnInit(): void {
    this.useremail = this.authService.getUseremail();
    console.log(this.useremail);
    this.authService.getUserByEmail(this.useremail).subscribe(
      (res) => {
        this.user = res;
        console.log(this.user);
        this.getFeedbacks();
      },
      (error) => {
        console.error('Error fetching user by email:', error);
      }
    );
  }

  getFeedbacks() {
    console.log(this.user.userId);
    this.feedbackService.getAllFeedbacksByUserId(this.user.userId).subscribe((res) => {
      this.feedbacks = res;
      this.updatePagination(); // Update pagination after loading data
    });
  }

  updatePagination() {
    this.totalPages = Math.ceil(this.feedbacks.length / this.itemsPerPage);
    this.paginate();
  }

  paginate() {
    const startIndex = (this.currentPage - 1) * this.itemsPerPage;
    const endIndex = startIndex + this.itemsPerPage;
    this.paginatedFeedbacks = this.feedbacks.slice(startIndex, endIndex);
  }

  goToPage(page: number) {
    if (page >= 1 && page <= this.totalPages) {
      this.currentPage = page;
      this.paginate();
    }
  }

  previousPage() {
    if (this.currentPage > 1) {
      this.currentPage--;
      this.paginate();
    }
  }

  nextPage() {
    if (this.currentPage < this.totalPages) {
      this.currentPage++;
      this.paginate();
    }
  }

  getPages(): number[] {
    const pages: number[] = [];
    for (let i = 1; i <= this.totalPages; i++) {
      pages.push(i);
    }
    return pages;
  }

  confirmDelete(feedbackId: number) {
    this.feedbackToDelete = feedbackId;
    this.showConfirmDelete = true;
  }

  deleteFeedback() {
    if (this.feedbackToDelete !== null) {
      this.feedbackService.deleteFeedback(this.feedbackToDelete).subscribe(
        () => {
          this.showSuccessModal = true;
          this.getFeedbacks();
          this.feedbackToDelete = null;
          this.showConfirmDelete = false;
        },
        (error) => {
          this.showFailureModal = true;
          this.feedbackToDelete = null;
          this.showConfirmDelete = false;
        }
      );
    }
  }

  cancelDelete() {
    this.showConfirmDelete = false;
    this.feedbackToDelete = null;
  }

  closeModal() {
    this.showSuccessModal = false;
    this.showFailureModal = false;
  }
}