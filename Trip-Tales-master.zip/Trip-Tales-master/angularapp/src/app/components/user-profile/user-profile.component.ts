import { Component, OnInit } from '@angular/core';
import { Loyalty } from 'src/app/models/loyalty.model';
import { User } from 'src/app/models/user.model';
import { AuthService } from 'src/app/services/auth.service';
import { LoyaltyService } from 'src/app/services/loyalty.service';

@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.css']
})
export class UserProfileComponent implements OnInit {

  useremail: string = '';

  user: User = {
    userId: 0,
    email: '',
    password: '',
    username: '',
    mobileNumber: '',
    userRole: ''
  }

  loyalty:Loyalty={
    loyaltyPoints:0,
    loyaltyLevel:0
  }

  constructor(private readonly authService:AuthService,private readonly loyaltyService:LoyaltyService) { }

  ngOnInit(): void {
    this.useremail = this.authService.getUseremail();
    this.authService.getUserByEmail(this.useremail).subscribe(
      (res) => {
        this.user = res;
        this.loyaltyService.getLoyaltyPointsByUserId(this.user.userId).subscribe((res)=>{
          this.loyalty=res;
        })
      },
      (error) => {
        console.error('Error fetching user by email:', error);
      }
    );
    
  }

}
