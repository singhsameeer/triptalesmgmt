import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  successMessage:boolean=false
  isError:boolean=false
  errorMessage: string = '';
  
  constructor(private readonly authService: AuthService, private readonly router: Router, private readonly formBuilder: FormBuilder) { }

  ngOnInit(): void {
    this.loginForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.pattern(/^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/)]],
      password: ['', [Validators.required, Validators.pattern(/^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[!@#$%^&*]).{6,16}$/)]]
    });
  }

  login() {
    if (this.loginForm.valid) {
      this.authService.login(this.loginForm.value).subscribe((userToken) => {
        const token = userToken.token;
        localStorage.setItem('token', token);
        this.successMessage = true;
        this.isError = false;
        this.errorMessage = '';
        setTimeout(() => {
          this.router.navigate(['/']);
        }, 1500); 
      },
      (error: HttpErrorResponse) => {
        console.error('An error occurred:', error);
        this.errorMessage = error.error.message || 'An unknown error occurred!';
        this.isError = true;
      });
    }
  }

  cancel() {
    this.router.navigate(['/']);
  }

  get f() {
    return this.loginForm.controls
  }
}
