import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TripDetails } from 'src/app/models/trip-details.model';
import { TripService } from 'src/app/services/trip.service';

@Component({
  selector: 'app-adminviewtrip',
  templateUrl: './adminviewtrip.component.html',
  styleUrls: ['./adminviewtrip.component.css']
})
export class AdminviewtripComponent implements OnInit {
  // Array to hold trip details data
  tripDetails: TripDetails[] = [];
  // Paginated trips to display on the current page
  paginatedTrips: TripDetails[] = [];
  // Number of trips to display per page
  itemsPerPage: number = 8;
  // Current page number
  currentPage: number = 1;
  // Total number of pages
  totalPages: number = 0;
  // Variable to store error messages
  errorMessage: string = '';
  // Variable to store the ID of the trip to be deleted
  tripIdToDelete: number = 0;
  // Flag to show/hide the delete confirmation popup
  showDeletePopup: boolean = false;
  // Flag to show/hide the success message modal
  showSuccessMessage: boolean = false;
  // Flag to show/hide the failure message modal
  showFailureMessage: boolean = false;

  // Constructor to inject TripService and Router
  constructor(private readonly service: TripService, private readonly router: Router) { }

  // Function to load all trip details from the server
  loadBookings() {
    this.service.getAllTripDetails().subscribe(
      (res) => {
        // Assign the fetched trip details to the array
        this.tripDetails = res;
        this.totalPages = Math.ceil(this.tripDetails.length / this.itemsPerPage);
        this.updatePaginatedTrips(); // Update paginated trips
      },
      (error: HttpErrorResponse) => {
        // Handle error and set the error message
        console.error("Error loading trips");
        this.errorMessage = error.error;
      }
    );
  }

  // Lifecycle hook that is called after Angular has initialized all data-bound properties
  ngOnInit(): void {
    this.loadBookings();
  }

  // Update the paginated trips based on the current page
  updatePaginatedTrips(): void {
    const startIndex = (this.currentPage - 1) * this.itemsPerPage;
    const endIndex = startIndex + this.itemsPerPage;
    this.paginatedTrips = this.tripDetails.slice(startIndex, endIndex);
  }

  // Go to a specific page
  goToPage(page: number): void {
    if (page >= 1 && page <= this.totalPages) {
      this.currentPage = page;
      this.updatePaginatedTrips();
    }
  }

  // Go to the previous page
  previousPage(): void {
    if (this.currentPage > 1) {
      this.currentPage--;
      this.updatePaginatedTrips();
    }
  }

  // Go to the next page
  nextPage(): void {
    if (this.currentPage < this.totalPages) {
      this.currentPage++;
      this.updatePaginatedTrips();
    }
  }

  // Get an array of page numbers for the pagination controls
  getPages(): number[] {
    const pages: number[] = [];
    for (let i = 1; i <= this.totalPages; i++) {
      pages.push(i);
    }
    return pages;
  }

  // Function to confirm the delete action and show the confirmation popup
  confirmDelete(tripId: number) {
    this.tripIdToDelete = tripId;
    this.showDeletePopup = true;
  }

  // Function to delete a trip and handle success and failure scenarios
  deleteTrip() {
    this.service.deleteTrip(this.tripIdToDelete).subscribe(
      () => {
        // Show success message and hide failure message
        this.showSuccessMessage = true;
        this.showFailureMessage = false;
        this.showDeletePopup = false;
        // Reload the trip details after deletion
        this.loadBookings();
      },
      () => {
        // Show failure message and hide success message
        this.showFailureMessage = true;
        this.showSuccessMessage = false;
        this.showDeletePopup = false;
        console.error("Error deleting trip");
      }
    );
  }

  // Function to cancel the delete action and hide the confirmation popup
  cancelDelete() {
    this.showDeletePopup = false;
  }

  // Function to close the success message modal
  closeSuccessModal() {
    this.showSuccessMessage = false;
  }

  // Function to close the failure message modal
  closeFailureModal() {
    this.showFailureMessage = false;
  }

  // Function to navigate to the edit trip page
  edit(tripId: number) {
    this.router.navigate(['/edit-trip', tripId]);
  }
}