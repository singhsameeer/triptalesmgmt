import { ComponentFixture, TestBed } from '@angular/core/testing';
import { UserTravellerApplicationsComponent } from './user-traveller-applications.component';

describe('UserTravellerApplicationsComponent', () => {
  let component: UserTravellerApplicationsComponent;
  let fixture: ComponentFixture<UserTravellerApplicationsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserTravellerApplicationsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UserTravellerApplicationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
