import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TravellerApplication } from 'src/app/models/traveller-application.model';
import { User } from 'src/app/models/user.model';
import { AuthService } from 'src/app/services/auth.service';
import { TravellerService } from 'src/app/services/traveller.service';

@Component({
  selector: 'app-user-traveller-applications',
  templateUrl: './user-traveller-applications.component.html',
  styleUrls: ['./user-traveller-applications.component.css']
})
export class UserTravellerApplicationsComponent implements OnInit {
  travellers: TravellerApplication[] = [];
  paginatedTravellers: TravellerApplication[] = [];
  itemsPerPage: number = 8;
  currentPage: number = 1;
  totalPages: number = 0;
  errorMessage: string = '';
  user: User = {
    userId: 0,
    email: '',
    password: '',
    username: '',
    mobileNumber: '',
    userRole: ''
  };

  constructor(
    private readonly service: TravellerService,
    private readonly authService: AuthService,
    private readonly router: Router
  ) {}

  ngOnInit(): void {
    const userEmail = this.authService.getUseremail();
    this.authService.getUserByEmail(userEmail).subscribe((res) => {
      this.user = res;
      this.getTrips(this.user.userId);
    });
  }

  getTrips(userId: number) {
    this.service.findTravellerApplicationsByUserId(userId).subscribe(
      (res) => {
        this.travellers = res;
        this.totalPages = Math.ceil(this.travellers.length / this.itemsPerPage);
        this.updatePaginatedTravellers();
      },
      (error: HttpErrorResponse) => {
        console.error("Error loading traveller applications");
        this.errorMessage = error.error;
      }
    );
  }

  updatePaginatedTravellers(): void {
    const startIndex = (this.currentPage - 1) * this.itemsPerPage;
    const endIndex = startIndex + this.itemsPerPage;
    this.paginatedTravellers = this.travellers.slice(startIndex, endIndex);
  }

  goToPage(page: number): void {
    if (page >= 1 && page <= this.totalPages) {
      this.currentPage = page;
      this.updatePaginatedTravellers();
    }
  }

  previousPage(): void {
    if (this.currentPage > 1) {
      this.currentPage--;
      this.updatePaginatedTravellers();
    }
  }

  nextPage(): void {
    if (this.currentPage < this.totalPages) {
      this.currentPage++;
      this.updatePaginatedTravellers();
    }
  }

  getPages(): number[] {
    const pages: number[] = [];
    for (let i = 1; i <= this.totalPages; i++) {
      pages.push(i);
    }
    return pages;
  }

  payment(tripId: number) {
    this.router.navigate(['/user-payment', tripId]);
  }
}