import { Component } from '@angular/core';

@Component({
  selector: 'app-traveller-application',
  templateUrl: './traveller-application.component.html',
  styleUrls: ['./traveller-application.component.css']
})
export class TravellerApplicationComponent{

  constructor() { }
}
