import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Feedback } from 'src/app/models/feedback.model';
import { User } from 'src/app/models/user.model';
import { AuthService } from 'src/app/services/auth.service';
import { FeedbackService } from 'src/app/services/feedback.service';


@Component({
  selector: 'app-useraddfeedback',
  templateUrl: './useraddfeedback.component.html',
  styleUrls: ['./useraddfeedback.component.css']
})
export class UseraddfeedbackComponent implements OnInit {
  // Form group to manage the feedback form
  feedBackForm: FormGroup;
  // Flags to show/hide success and failure modals
  showSuccessModal: boolean = false;
  showFailureModal: boolean = false;
  // Feedback object to hold feedback data
  feedback: Feedback = {
    feedbackText: ''
  };
  // User object to hold user data
  user: User = {
    userId: 0,
    email: '',
    password: '',
    username: '',
    mobileNumber: '',
    userRole: ''
  };
  // Variable to store user's email
  useremail: string = '';

  // Constructor to inject FormBuilder, AuthService, FeedbackService, and Router
  constructor(private readonly formBuilder: FormBuilder, private readonly authService: AuthService, private readonly feedbackService: FeedbackService, private readonly route: Router) { }

  // Lifecycle hook that is called after Angular has initialized all data-bound properties
  ngOnInit(): void {

    // Retrieve user's email from AuthService
    this.useremail = this.authService.getUseremail();

    // Fetch user data by email
    this.authService.getUserByEmail(this.useremail).subscribe(
      (res) => {
        this.user = res;
      },
      (error) => {
        console.error('Error fetching user by email:', error);
      }
    );

    // Initialize the feedback form with form controls and validators
    this.feedBackForm = this.formBuilder.group({
      feedbackText: ['', [Validators.required, Validators.minLength(5)]]
    });
  }

  // Function to send feedback
  sendFeedback() {
    if (this.feedBackForm.valid) {
      // Set the feedback text from the form
      this.feedback.feedbackText = this.feedBackForm.get('feedbackText').value;
      
      // Ensure the feedback user is set correctly
      this.feedback.user = this.user;
      
      // Call the sendFeedback method from FeedbackService to send the feedback
      this.feedbackService.sendFeedback(this.feedback).subscribe(() => {
      // Show success modal on successful feedback submission
          this.showSuccessModal = true;
          // Navigate to the user view feedback page after a short delay
          setTimeout(() => {
            this.route.navigate(['/userview-feedback']);
            this.closeModal();
          }, 2000);
        },(error) => {
            this.route.navigate(['/userview-feedback'])
            this.closeModal()
          });
    }
    // Reset the feedback form
    this.feedBackForm.reset();
  }

  // Getter for form controls
  get f() {
    return this.feedBackForm.controls;
  }

  // Function to close success and failure modals
  closeModal() {
    this.showSuccessModal = false;
    this.showFailureModal = false;
  }
}
