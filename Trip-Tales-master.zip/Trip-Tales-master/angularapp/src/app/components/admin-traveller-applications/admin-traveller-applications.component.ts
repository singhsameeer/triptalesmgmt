import { Component, OnInit } from '@angular/core';
import { TravellerApplication } from 'src/app/models/traveller-application.model';
import { User } from 'src/app/models/user.model';
import { TravellerService } from 'src/app/services/traveller.service';

@Component({
  selector: 'app-admin-traveller-applications',
  templateUrl: './admin-traveller-applications.component.html',
  styleUrls: ['./admin-traveller-applications.component.css']
})
export class AdminTravellerApplicationsComponent implements OnInit {
  user: User = {
    email: '',
    password: '',
    username: '',
    mobileNumber: '',
    userRole: ''
  };

  travellers: TravellerApplication[] = [];
  filteredTravellers: TravellerApplication[] = [];
  paginatedTravellers: TravellerApplication[] = [];
  showApproveModal: boolean = false;
  showDenyModal: boolean = false;
  errorMessage: string = '';
  selectedStatus: string = 'All';

  // Pagination properties
  currentPage: number = 1;
  itemsPerPage: number = 7;
  totalPages: number = 0;

  constructor(private readonly travellerService: TravellerService) {}

  loadBookings() {
    this.travellerService.getAllTravellerApplication().subscribe((res) => {
      this.travellers = res;
      this.filterTravellers(); // Filter travellers based on initial status
      this.updatePagination(); // Update pagination after loading data
    }, (error) => {
      console.error("Error loading trips");
      this.errorMessage = "Error loading trips";
    });
  }

  filterTravellers() {
    if (this.selectedStatus === 'All') {
      this.filteredTravellers = this.travellers;
    } else {
      this.filteredTravellers = this.travellers.filter(
        (traveller) => traveller.paymentStatus === this.selectedStatus
      );
    }
    this.updatePagination(); // Update pagination after filtering
  }

  updatePagination() {
    this.totalPages = Math.ceil(this.filteredTravellers.length / this.itemsPerPage);
    this.paginate();
  }

  paginate() {
    const startIndex = (this.currentPage - 1) * this.itemsPerPage;
    const endIndex = startIndex + this.itemsPerPage;
    this.paginatedTravellers = this.filteredTravellers.slice(startIndex, endIndex);
  }

  goToPage(page: number) {
    if (page >= 1 && page <= this.totalPages) {
      this.currentPage = page;
      this.paginate();
    }
  }

  previousPage() {
    if (this.currentPage > 1) {
      this.currentPage--;
      this.paginate();
    }
  }

  nextPage() {
    if (this.currentPage < this.totalPages) {
      this.currentPage++;
      this.paginate();
    }
  }

  getPages(): number[] {
    const pages: number[] = [];
    for (let i = 1; i <= this.totalPages; i++) {
      pages.push(i);
    }
    return pages;
  }

  updateStatus(status: string, id: number) {
    this.travellerService.updatePaymentStatus(id, status).subscribe(() => {
      this.loadBookings();
      if (status === 'approved') {
        this.showApproveModal = true;
      } else if (status === 'denied') {
        this.showDenyModal = true;
      }
      setTimeout(() => {
        this.closeModals();
      }, 2000);
    });
  }

  showUser(userDetails: User) {
    this.user = userDetails;
  }

  closeModal() {
    this.user = {
      userId: 0,
      email: '',
      password: '',
      username: '',
      mobileNumber: '',
      userRole: ''
    };
  }

  closeModals() {
    this.showApproveModal = false;
    this.showDenyModal = false;
  }

  // Lifecycle hook that is called after Angular has initialized all data-bound properties
  ngOnInit(): void {
    this.loadBookings();
  }
}
