import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-usernav',
  templateUrl: './usernav.component.html',
  styleUrls: ['./usernav.component.css']
})
export class UsernavComponent{

  // Instance of the authentication service
  auth: any = this.authService;
  // Flag to show/hide the logout confirmation popup
  showLogoutPopup: boolean = false;

  // Constructor to inject AuthService and Router
  constructor(private readonly authService: AuthService, private readonly router: Router) { }


  // Function to show the logout confirmation popup
  logout() {
    this.showLogoutPopup = true;
  }

  // Function to confirm the logout action, log the user out, and navigate to the home page
  confirmLogout() {
    this.authService.logout();
    setTimeout(() => {
      this.router.navigate(['/']);
    }, 1000);
    this.showLogoutPopup = false;
  }

  // Function to cancel the logout action and hide the confirmation popup
  cancelLogout() {
    this.showLogoutPopup = false;
  }

  onKeyDown(event: KeyboardEvent) {
    console.log('Key pressed:', event.key);
  }

}
