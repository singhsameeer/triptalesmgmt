import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, AbstractControl, ValidationErrors, ValidatorFn, NG_VALIDATORS } from '@angular/forms';
import { Router } from '@angular/router';
import { TripDetails } from 'src/app/models/trip-details.model';
import { TripService } from 'src/app/services/trip.service';

export function seatsValidator(): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const totalSeats = control.get('totalSeats')?.value;
    const availableSeats = control.get('availableSeats')?.value;
    return availableSeats <= totalSeats ? null : { seatsMismatch: true };
  };
}

@Component({
  selector: 'app-createtrip',
  templateUrl: './createtrip.component.html',
  styleUrls: ['./createtrip.component.css']
})
export class CreatetripComponent implements OnInit {
  // Form group to manage the trip creation form
  addTripForm: FormGroup;
  // Array of available locations for trips
  availableLocations: string[] = ["Jaipur", "Jodhpur", "Udaipur",
  "Dehradun", "Rishikesh", "Manali", "Leh",
  "Kochi", "Alleppey", "Munnar",
  "Panaji", "Calangute", "Anjuna",
  "Gangtok", "Lachung", "Pelling",
  "Jaisalmer", "Bikaner", "Pushkar",
  "Kolkata", "Shantiniketan", "Sundarbans",
  "Shimla", "Kullu", "Manali",
  "Varanasi", "Sarnath", "Allahabad",
  "Chennai", "Pondicherry", "Madurai", "Kanyakumari",
  "Goa", "Agra", "Delhi", "Mumbai", "Bengaluru", "Hyderabad",
  "Darjeeling", "Ooty", "Amritsar", "Puducherry"];
  // Array to store selected locations for the trip
  selectedLocations: string[] = [];
  // Flags to show/hide success and failure modals
  showSuccessModal: boolean = false;
  showFailureModal: boolean = false;
  errormessage:string='';
  minDate: string='';

  // Constructor to inject FormBuilder, TripService, and Router
  locationErrorMessage:string=''

  constructor(private readonly formBuilder: FormBuilder, private readonly tripService: TripService, private readonly router: Router) { }

  // Lifecycle hook that is called after Angular has initialized all data-bound properties
  ngOnInit(): void {
    // Initialize the trip creation form with form controls and validators
    this.addTripForm = this.formBuilder.group({
      tripName: ['', [Validators.required,Validators.pattern(/^[A-Za-z ]{4,}$/)]],
      tripDuration: ['', [Validators.required, Validators.min(1)]],
      tripPrice: ['', [Validators.required, Validators.min(1000)]],
      tripStartLocation: ['', Validators.required],
      tripLocations: ['', Validators.required],
      date: ['', Validators.required],
      totalSeats: ['', [Validators.required, Validators.min(1)]],
      availableSeats: ['', [Validators.required, Validators.min(1)]],
      points: ['', [Validators.required, Validators.min(0)]]
    }, { validators: seatsValidator() });

    // Get today's date in YYYY-MM-DD format
    const today = new Date();
    const day = String(today.getDate()).padStart(2, '0');
    const month = String(today.getMonth() + 1).padStart(2, '0'); // Months are 0-based
    const year = today.getFullYear();
    this.minDate = `${year}-${month}-${day}`;

  }

  // Getter for form controls
  get f() {
    return this.addTripForm.controls;
  }

  // Function to add a location to the selected locations array
  addLocation() {
    const location = this.addTripForm.get('tripLocations')?.value;
    if(this.selectedLocations.includes(location)){
      this.locationErrorMessage='Location already selected'
    }
    else if (location && !this.selectedLocations.includes(location)) {
      this.selectedLocations.push(location);
      this.addTripForm.get('tripLocations')?.reset();
      this.locationErrorMessage='';
    }
    // Set validation errors for tripLocations form control based on selected locations array
    if (this.selectedLocations.length > 0) {
      this.addTripForm.get('tripLocations')?.setErrors(null);
    } else {
      this.addTripForm.get('tripLocations')?.setErrors({ required: true });
    }
  }

  // Function to remove a location from the selected locations array
  remove(index: number) {
    this.selectedLocations.splice(index, 1);
    // Set validation errors for tripLocations form control based on selected locations array
    if (this.selectedLocations.length > 0) {
      this.addTripForm.get('tripLocations')?.setErrors(null);
    } else {
      this.addTripForm.get('tripLocations')?.setErrors({ required: true });
    }
  }

  // Function to add a new trip using the trip service
  addTrip() {
    if (this.addTripForm.valid) {
      const formData = this.addTripForm.value;
      const tripData: TripDetails = {
        tripName: formData.tripName,
        tripDuration: formData.tripDuration,
        tripPrice: formData.tripPrice,
        tripStartLocation: formData.tripStartLocation,
        tripLocations: this.selectedLocations,
        date: formData.date,
        totalSeats: formData.totalSeats,
        availableSeats: formData.availableSeats,
        points: formData.points
      };
      // Call the addTrip method from TripService to add the new trip
      this.tripService.addTrip(tripData).subscribe((res) => {
          // Show success modal on successful trip addition
          this.showSuccessModal = true;
        },(error:HttpErrorResponse) => {
          // Show failure modal on trip addition failure
          this.errormessage=error.error
          this.showFailureModal = true;
        }
      );
    }
  }

  // Function to close success and failure modals
  closeModals() {
    this.showSuccessModal = false;
    this.showFailureModal = false;
  }

  // Function to navigate to the admin view trips page after successful trip addition
  navigateToTrips() {
    this.showSuccessModal = false;
    this.router.navigate(['/adminview-trip']);
  }

  preventInvalidInput(event: KeyboardEvent) {
    if (['e', 'E', '+', '-'].includes(event.key)) {
      event.preventDefault();
    }
  }
}
