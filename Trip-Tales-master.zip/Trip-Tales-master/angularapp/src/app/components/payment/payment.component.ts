import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Loyalty } from 'src/app/models/loyalty.model';
import { TravellerApplication } from 'src/app/models/traveller-application.model';
import { TripDetails } from 'src/app/models/trip-details.model';
import { User } from 'src/app/models/user.model';
import { LoyaltyService } from 'src/app/services/loyalty.service';
import { TravellerService } from 'src/app/services/traveller.service';
import { TripService } from 'src/app/services/trip.service';
 
@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {
  numberOfSeats = 1;
  originalPrice: number;
  loyaltyPoints: number=0;
  discountAmount: number=0;
  finalPrice: number=0;
  id:number=0;

  paymentMessage: string;
  showModal: boolean = false;
  autoNavigateTimeout: any; 

  user:User={
    email: '',
    password: '',
    username: '',
    mobileNumber: '',
    userRole: ''
  }
  trip:TripDetails={
    tripName: '',
    tripDuration: 0,
    tripPrice: 0,
    tripStartLocation: '',
    tripLocations: [],
    date: '',
    totalSeats: 0,
    availableSeats: 0,
    points: 0
  }
  loyalty:Loyalty={
    loyaltyPoints: 0,
    user:this.user,
    loyaltyLevel:0,
    benefits:[],
    claimedInitialPoints:false
  }
  traveller:TravellerApplication={
    id:0,
    user:this.user,
    tripDetails:this.trip,
    paymentStatus:''
  }
  constructor(
    private readonly service:LoyaltyService,
    private readonly activatedRoute:ActivatedRoute,
    private readonly tripService:TripService, 
    private readonly travellerService:TravellerService,
    private readonly router:Router
    ) { }
 
  ngOnInit(): void {
    this.id = +this.activatedRoute.snapshot.paramMap.get('id');
    console.log(this.id)
    this.travellerService.findTravellerApplicationById(this.id).subscribe((res)=>{
      this.traveller=res;
      console.log(res)
      this.loadTripDetails();
      this.loadLoyaltyPoints();
    })
  }
 
  loadTripDetails() {
    this.tripService.findTripById(this.traveller.tripDetails.tripId).subscribe((res) => {
      this.trip = res;
      this.originalPrice = this.trip.tripPrice;
      this.calculateFinalPrice();
    });
  }
 
  loadLoyaltyPoints() {
    this.service.getLoyaltyPointsByUserId(this.traveller.user.userId).subscribe((res) => {
      this.loyalty = res;
      console.log(this.loyalty)
      this.loyaltyPoints=this.loyalty.loyaltyPoints
      this.calculateFinalPrice();
    });
  }
 
  calculateFinalPrice() {
    if (this.originalPrice && this.loyalty !== undefined) {
      this.finalPrice = (this.originalPrice * this.numberOfSeats) - (this.calDiscount(this.loyaltyPoints)*this.numberOfSeats);
    }
  }
 
  calDiscount(points: number) {
    if(points==0){
      return 0;
    }
   else  if (points >= 100 && points < 200) {
      this.discountAmount = (this.originalPrice * 0.1) ;
    } else if (points >= 200 && points < 300) {
      this.discountAmount = (this.originalPrice * 0.15) ;
    } else if (points >= 300 && points < 400) {
      this.discountAmount = (this.originalPrice * 0.20);
    } else {
      this.discountAmount = (this.originalPrice * 0.25);
    }
    return this.discountAmount;
  }
 
  increaseSeats() {
    if (this.numberOfSeats < 5 && this.numberOfSeats < this.trip.availableSeats) {
      this.numberOfSeats++;
      this.calculateFinalPrice();
    }
  }
 
  decreaseSeats() {
    if (this.numberOfSeats > 1) {
      this.numberOfSeats--;
      this.calculateFinalPrice();
    }
  }
  
  confirmPayment() {
    if (this.traveller.id && this.traveller.user.userId && this.numberOfSeats) {
      console.log(this.traveller)
      console.log(this.user)
      this.travellerService.updateLoyaltyAndStatus(this.traveller.id, this.traveller.user.userId, this.numberOfSeats).subscribe(() => {
        this.paymentMessage = "Payment Successful!";
        this.showModal = true;
        this.autoNavigate();
      }, (error: HttpErrorResponse) => {
        if(error.error=='Loyalty not found'){
          this.paymentMessage="Claim loyalty to get discount and Make payment"
          this.showModal = true
          this.router.navigate(['/claim-loyalty'])
        }else{
          this.paymentMessage = "Payment Failed!";
          console.log(error.error);
          this.showModal = true; 
          this.autoNavigate(); 
        }
      })
    } else {
      console.error('Required data is not available.');
    }
  }

  autoNavigate() {
    this.autoNavigateTimeout = setTimeout(() => {
      this.navigateToApplication();
    }, 1500); 
  }

  navigateToApplication() {
    this.showModal = false;
    clearTimeout(this.autoNavigateTimeout); 
    this.router.navigate(['/user-traveller-application']); 
  }
}