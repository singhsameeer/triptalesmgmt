import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TripDetails } from 'src/app/models/trip-details.model';
import { TripService } from 'src/app/services/trip.service';

@Component({
  selector: 'app-viewtrip',
  templateUrl: './viewtrip.component.html',
  styleUrls: ['./viewtrip.component.css']
})
export class ViewtripComponent implements OnInit {
  // Array to hold trip details data
  tripDetails: TripDetails[] = [];
  // Paginated trips to display on the current page
  paginatedTrips: TripDetails[] = [];
  // Number of trips to display per page
  itemsPerPage: number = 8;
  // Current page number
  currentPage: number = 1;
  // Total number of pages
  totalPages: number = 0;
  // Variable to store error messages
  errorMessage: string = '';
  // Flag to indicate if the trip list is empty
  isEmpty: boolean = false;
  // Variable to store the current sort direction ('asc' or 'desc')
  sortDirection: 'asc' | 'desc' = 'asc';
  // Variable to store the trip name for search functionality
  tripName: string = '';

  // Constructor to inject TripService and Router
  constructor(private readonly tripService: TripService, private readonly router: Router) { }

  // Lifecycle hook that is called after Angular has initialized all data-bound properties
  ngOnInit(): void {
    this.loadBookings();
  }

  // Function to load all trip details from the server
  loadBookings() {
    this.tripService.getAllTripDetails().subscribe(
      (data) => {
        // Assign the fetched trip details to the array
        this.tripDetails = data;
        this.totalPages = Math.ceil(this.tripDetails.length / this.itemsPerPage);
        this.updatePaginatedTrips(); // Update paginated trips
      },
      (error) => {
        // Handle error and set the error message
        console.error('Error loading trips', error);
        this.errorMessage = "Error Loading trips";
      }
    );
  }

  // Update the paginated trips based on the current page
  updatePaginatedTrips(): void {
    const startIndex = (this.currentPage - 1) * this.itemsPerPage;
    const endIndex = startIndex + this.itemsPerPage;
    this.paginatedTrips = this.tripDetails.slice(startIndex, endIndex);
  }

  // Go to a specific page
  goToPage(page: number): void {
    if (page >= 1 && page <= this.totalPages) {
      this.currentPage = page;
      this.updatePaginatedTrips();
    }
  }

  // Go to the previous page
  previousPage(): void {
    if (this.currentPage > 1) {
      this.currentPage--;
      this.updatePaginatedTrips();
    }
  }

  // Go to the next page
  nextPage(): void {
    if (this.currentPage < this.totalPages) {
      this.currentPage++;
      this.updatePaginatedTrips();
    }
  }

  // Get an array of page numbers for the pagination controls
  getPages(): number[] {
    const pages: number[] = [];
    for (let i = 1; i <= this.totalPages; i++) {
      pages.push(i);
    }
    return pages;
  }

  // Function to sort bookings by price in ascending or descending order
  sortBookings(direction: 'asc' | 'desc') {
    this.sortDirection = direction;
    if (this.sortDirection === 'asc') {
      this.tripService.getTripsSortedByPrice('ascending').subscribe(
        (data) => {
          this.tripDetails = data; // Assign the sorted data to tripDetails
          this.totalPages = Math.ceil(this.tripDetails.length / this.itemsPerPage);
          this.updatePaginatedTrips(); // Update paginated trips
          this.isEmpty = this.tripDetails.length === 0;
        },
        (error) => {
          console.error('Error sorting trips', error);
          this.errorMessage = "Error sorting trips";
        }
      );
    } else {
      this.tripService.getTripsSortedByPrice('descending').subscribe(
        (data) => {
          this.tripDetails = data; // Assign the sorted data to tripDetails
          this.totalPages = Math.ceil(this.tripDetails.length / this.itemsPerPage);
          this.updatePaginatedTrips(); // Update paginated trips
          this.isEmpty = this.tripDetails.length === 0;
        },
        (error) => {
          console.error('Error sorting trips', error);
          this.errorMessage = "Error sorting trips";
        }
      );
    }
  }

  // Function to search for trips by name
  search() {
    if (this.tripName !== '') {
      this.tripService.searchTripsByName(this.tripName).subscribe(
        (res) => {
          this.isEmpty = false;
          this.tripDetails = res;
          this.totalPages = Math.ceil(this.tripDetails.length / this.itemsPerPage);
          this.updatePaginatedTrips(); // Update paginated trips
        },
        (error) => {
          this.isEmpty = true;
          this.errorMessage = "No Match found";
        }
      );
    }
  }

  // Function to clear the search input and reload all bookings
  clearSearch() {
    this.tripName = '';
    this.isEmpty = false;
    this.loadBookings();
  }

  // Function to navigate to the booking confirmation page
  bookTrip(tripId: number) {
    this.router.navigate(['/confirm-booking', tripId]);
  }
}