package com.examly.springapp.service; // Define the package name

import java.util.ArrayList; // Import necessary classes
import java.util.List; // Import List class
import java.util.Optional; // Import Optional class

import org.springframework.stereotype.Service; // Import Service annotation

import com.examly.springapp.dto.LoyaltyDTO;
import com.examly.springapp.exceptions.InsufficientLoyaltyPointsException;
import com.examly.springapp.exceptions.LoyaltyNotFoundException;
import com.examly.springapp.exceptions.UserNotFoundException;
import com.examly.springapp.model.Loyalty; // Import Loyalty model
import com.examly.springapp.model.User; // Import User model
import com.examly.springapp.repository.LoyaltyRepo; // Import Loyalty repository
import com.examly.springapp.repository.UserRepo; // Import User repository

import lombok.RequiredArgsConstructor;

@Service // Mark this class as a service
@RequiredArgsConstructor
public class LoyaltyServiceImpl implements LoyaltyService { // Implement LoyaltyService interface


    private final UserRepo userRepo; // Inject User repository

    private final LoyaltyRepo loyaltyRepo; // Inject Loyalty repository

    private String[] benefitsArray = {"Zero Cancellation Fee", "50% Discount", "Premium User"};
    
    private static final String USER_NOT_FOUND="User not found!";

    @Override
    public Loyalty getLoyaltyPointsByUserId(int userId)throws LoyaltyNotFoundException {
        // Get loyalty points by user ID
        Optional<Loyalty> loyalty=loyaltyRepo.findByUserId(userId);
        if(loyalty.isEmpty()){
            throw new LoyaltyNotFoundException("Loyalty not found");
        }
        return loyalty.get();
    }

    @Override
    public Loyalty addLoyalty(int userId, LoyaltyDTO loyalty) throws UserNotFoundException {
        // Add loyalty points for a user
        Optional<User> user = userRepo.findById(userId);
        if (user.isEmpty()) {
            throw new UserNotFoundException(USER_NOT_FOUND);
        }
        Optional<Loyalty> loyaltyByUser = loyaltyRepo.findByUserId(userId);
        Loyalty newLoyalty = new Loyalty();
        if (loyaltyByUser.isEmpty()) {
            newLoyalty.setUser(user.get());
            newLoyalty.setLoyaltyPoints(loyalty.getLoyaltyPoints());
            newLoyalty.setLoyaltyLevel(1L);
            newLoyalty.setClaimedInitialPoints(true);
            List<String> benefits = new ArrayList<>();
            benefits.add(benefitsArray[0]);
            newLoyalty.setBenefits(benefits);
            newLoyalty = loyaltyRepo.save(newLoyalty);
        }
        return newLoyalty;
    }


    @Override
    public Loyalty updateLoyalty(int userId, Loyalty loyalty) throws InsufficientLoyaltyPointsException {
        // Update loyalty points for a user
        Optional<Loyalty> loyaltyByUser = loyaltyRepo.findByUserId(userId);
        if (loyaltyByUser.isPresent() && loyaltyByUser.get().getLoyaltyPoints() < 1) {
            throw new InsufficientLoyaltyPointsException("Insufficient loyalty points");
        }
        loyaltyByUser.get().setLoyaltyPoints(loyaltyByUser.get().getLoyaltyPoints() - loyalty.getLoyaltyPoints());
        if (loyaltyByUser.get().getLoyaltyPoints() <= 100) {
            loyaltyByUser.get().setLoyaltyLevel(1L);
            List<String> benefits = new ArrayList<>();
            benefits.add(benefitsArray[0]);
            loyaltyByUser.get().setBenefits(benefits);
        } else if (loyaltyByUser.get().getLoyaltyPoints() > 100 && loyaltyByUser.get().getLoyaltyPoints() <= 300) {
            loyaltyByUser.get().setLoyaltyLevel(2L);
            List<String> benefits = new ArrayList<>();
            benefits.add(benefitsArray[0]);
            benefits.add(benefitsArray[1]);
            loyaltyByUser.get().setBenefits(benefits);
        } else if (loyaltyByUser.get().getLoyaltyPoints() > 300 && loyaltyByUser.get().getLoyaltyPoints() <= 500) {
            loyaltyByUser.get().setLoyaltyLevel(3L);
            List<String> benefits = new ArrayList<>();
            benefits.add(benefitsArray[0]);
            benefits.add(benefitsArray[1]);
            benefits.add(benefitsArray[2]);
            loyaltyByUser.get().setBenefits(benefits);
        }
        return loyaltyRepo.save(loyalty);
    }
}