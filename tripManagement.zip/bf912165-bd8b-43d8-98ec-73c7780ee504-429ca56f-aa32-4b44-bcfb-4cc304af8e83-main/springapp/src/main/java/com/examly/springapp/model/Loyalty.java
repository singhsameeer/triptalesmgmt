package com.examly.springapp.model;

import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

import lombok.Data;

@Data
@Entity
public class Loyalty {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @NotNull(message = "User id cannot be null")
    @OneToOne
    @JoinColumn(name="userId")
    private User user;

    @NotNull(message = "Loyalty Points cannot be null")
    @Min(value=0, message="Loyalty Points can not be less than 0")
    private Long loyaltyPoints;

    @NotNull(message = "Loyalty Level cannot be null")
    @Min(value=1, message="Loyalty Level can not be less than 1")
    private Long loyaltyLevel;
    private List<String> benefits;
    private boolean claimedInitialPoints;
}
