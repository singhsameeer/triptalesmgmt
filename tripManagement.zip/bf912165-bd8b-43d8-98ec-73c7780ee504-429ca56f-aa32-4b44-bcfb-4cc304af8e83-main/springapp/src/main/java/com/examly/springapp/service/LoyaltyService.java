package com.examly.springapp.service;

import com.examly.springapp.dto.LoyaltyDTO;
import com.examly.springapp.exceptions.InsufficientLoyaltyPointsException;
import com.examly.springapp.exceptions.LoyaltyNotFoundException;
import com.examly.springapp.exceptions.UserNotFoundException;
import com.examly.springapp.model.Loyalty;


public interface LoyaltyService {

   Loyalty getLoyaltyPointsByUserId(int userId)throws LoyaltyNotFoundException  ;

   Loyalty addLoyalty(int userId, LoyaltyDTO loyalty)throws UserNotFoundException;

   Loyalty updateLoyalty(int userId, Loyalty loyalty) throws InsufficientLoyaltyPointsException;

}
