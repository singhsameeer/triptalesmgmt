package com.examly.springapp.controller; // Define the package name

import java.util.List; // Import necessary classes

import org.springframework.http.ResponseEntity; // Import ResponseEntity class
import org.springframework.web.bind.annotation.DeleteMapping; // Import DeleteMapping annotation
import org.springframework.web.bind.annotation.GetMapping; // Import GetMapping annotation
import org.springframework.web.bind.annotation.PathVariable; // Import PathVariable annotation
import org.springframework.web.bind.annotation.PutMapping; // Import PutMapping annotation
import org.springframework.web.bind.annotation.RequestBody; // Import RequestBody annotation
import org.springframework.web.bind.annotation.RequestMapping; // Import RequestMapping annotation
import org.springframework.web.bind.annotation.RestController; // Import RestController annotation

import com.examly.springapp.exceptions.UserNotFoundException;
import com.examly.springapp.model.User; // Import User model
import com.examly.springapp.service.UserService; // Import UserService class

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid; // Import Valid annotation
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
@RestController // Mark this class as a RestController
@RequestMapping("/api/user") // Define the base URL for user-related endpoints
@Tag(name = "User Controller", description = "Controller for managing users")
public class UserController {
    
    private final UserService userService; // Inject UserService
  
    @GetMapping
    @Operation(summary = "Get all users", description = "Retrieves all users")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successfully retrieved all users",
            content = @Content(mediaType = "application/json",
            schema = @Schema(implementation = User.class))),
        @ApiResponse(responseCode = "500", description = "Internal server error",
            content = @Content)
    })
    public ResponseEntity<List<User>> getAllUsers() throws UserNotFoundException {
        log.info("/api/user");
        // Handle GET request to retrieve all users and return the response
        return ResponseEntity.status(200).body(userService.getAllUsers());
    }

    @GetMapping("/{userId}")
    @Operation(summary = "Get user by ID", description = "Retrieves a user by their ID")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successfully retrieved user",
            content = @Content(mediaType = "application/json",
            schema = @Schema(implementation = User.class))),
        @ApiResponse(responseCode = "404", description = "User not found",
            content = @Content),
        @ApiResponse(responseCode = "500", description = "Internal server error",
            content = @Content)
    })
    public ResponseEntity<User> findUserById(@PathVariable int userId) throws UserNotFoundException {
        // Handle GET request to retrieve user by ID and return the response
        return ResponseEntity.status(200).body(userService.findUserById(userId));
    }

    @GetMapping("userEmail/{email}")
    @Operation(summary = "Get user by email", description = "Retrieves a user by their email")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successfully retrieved user",
            content = @Content(mediaType = "application/json",
            schema = @Schema(implementation = User.class))),
        @ApiResponse(responseCode = "404", description = "User not found",
            content = @Content),
        @ApiResponse(responseCode = "500", description = "Internal server error",
            content = @Content)
    })
    public ResponseEntity<User> getUserByEmail(@PathVariable String email) throws UserNotFoundException {
        // Handle GET request to retrieve user by email and return the response
        return ResponseEntity.status(200).body(userService.getUserByEmail(email));
    }

    @PutMapping("/{userId}")
    @Operation(summary = "Update user", description = "Updates a user's details by their ID")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "User updated successfully",
            content = @Content(mediaType = "application/json",
            schema = @Schema(implementation = User.class))),
        @ApiResponse(responseCode = "400", description = "Invalid input",
            content = @Content),
        @ApiResponse(responseCode = "404", description = "User not found",
            content = @Content),
        @ApiResponse(responseCode = "500", description = "Internal server error",
            content = @Content)
    })
    public ResponseEntity<User> updateUser(@PathVariable int userId, @Valid @RequestBody User user) throws UserNotFoundException {
        // Handle PUT request to update user details by ID and return the response
        return ResponseEntity.status(200).body(userService.updateUser(userId, user));
    }

    @DeleteMapping("deleteUser/{userId}")
    @Operation(summary = "Delete user", description = "Deletes a user by their ID")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "User deleted successfully",
            content = @Content),
        @ApiResponse(responseCode = "404", description = "User not found",
            content = @Content),
        @ApiResponse(responseCode = "500", description = "Internal server error",
            content = @Content)
    })
    public ResponseEntity<Object> deleteUser(@PathVariable int userId) throws UserNotFoundException {
        // Handle DELETE request to delete user by ID and return the response
        userService.deleteUser(userId);
        return ResponseEntity.status(200).build();
    }
}
