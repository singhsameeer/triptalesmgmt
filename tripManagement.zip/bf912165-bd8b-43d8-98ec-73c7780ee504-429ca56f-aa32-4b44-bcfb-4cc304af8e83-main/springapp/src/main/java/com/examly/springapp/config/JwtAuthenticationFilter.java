/*Define the package name,Import necessary classes,Import Autowired annotation,Import authentication token class
Import SecurityContextHolder class,Import UserDetails interface,Import WebAuthenticationDetailsSource class,
Import Component annotation,Import OncePerRequestFilter class,Import FilterChain class,
Import ServletException class,Import HttpServletRequest class,Import HttpServletResponse class
*/
 
package com.examly.springapp.config;
 
import java.io.IOException;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
 
import com.examly.springapp.service.UserServiceImpl;
 
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
 
// Mark this class as a Spring component,Inject JwtUtils,Inject UserServiceImpl
@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {
    @Autowired
    private JwtUtils jwtUtils;
    @Autowired
    private UserServiceImpl userServiceImpl;
   
    /*Extract token from the request, Validate the token, Extract the username from the token, Load user details using the username, Create authentication token
     Set additional details, Set authentication in the security context, Continue with the filter chain*/
    @SuppressWarnings("null")
    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        String token = jwtUtils.extractToken(request);
        if (token != null && jwtUtils.validateToken(token)) {
            String email = jwtUtils.extractEmailFromToken(token,"email");
            UserDetails userDetails = userServiceImpl.loadUserByUsername(email);
            UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(userDetails, null, userDetails.getAuthorities());
            authentication.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
            SecurityContextHolder.getContext().setAuthentication(authentication);
        }
        filterChain.doFilter(request, response);
    }
}