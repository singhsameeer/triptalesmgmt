
package com.examly.springapp.service; // Define the package name

import java.util.List; // Import necessary classes
import java.util.Optional; // Import Optional class

import org.springframework.stereotype.Service; // Import Service annotation

import com.examly.springapp.exceptions.TripAlreadyExistsException;
import com.examly.springapp.exceptions.TripNotFoundException;
import com.examly.springapp.model.TripDetails; // Import TripDetails model
import com.examly.springapp.repository.TravellerRepo;
import com.examly.springapp.repository.TripRepo; // Import Trip repository

import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;

@Service // Mark this class as a service
@RequiredArgsConstructor
public class TripServiceImpl implements TripService { // Implement TripService interface

    private final TripRepo tripRepo; // Inject Trip repository

    private final TravellerRepo travellerRepo; // Inject Traveller repository

    private static final  String TRIP_NOT_FOUND="Trip not found";
    private static final String TRIP_ALREADY_EXISTS="Trip already exists";

    @Override
    public TripDetails addTrip(TripDetails tripDetails) throws TripAlreadyExistsException {
        // Save and return the new trip details
        Optional<TripDetails> existingTrip=tripRepo.findByTripName(tripDetails.getTripName());
        if(existingTrip.isPresent()){
            throw new TripAlreadyExistsException(TRIP_ALREADY_EXISTS);
        }
        return tripRepo.save(tripDetails);
    }

    @Override
    public TripDetails findTripDetails(int tripId) throws TripNotFoundException {
        // Find trip details by ID
        Optional<TripDetails> tripDetails = tripRepo.findById(tripId);
        if (tripDetails.isEmpty()) {
            throw new TripNotFoundException(TRIP_NOT_FOUND);
        }
        return tripDetails.get();
    }

    @Override
    public List<TripDetails> findallTripDetails() {
        // Get all trip details
        return tripRepo.findAll();
    }

    @Override
    public TripDetails updateTripDetails(TripDetails tripDetails, int id) throws TripNotFoundException, TripAlreadyExistsException {
        // Update trip details by ID
        Optional<TripDetails> existingTripDetails = tripRepo.findById(id);
        if (existingTripDetails.isEmpty()) {
            throw new TripNotFoundException(TRIP_NOT_FOUND);
        }
        Optional<TripDetails> existingTripDetailsName=tripRepo.findByTripName(tripDetails.getTripName());
        if(existingTripDetailsName.isPresent()&&(existingTripDetails.get().getTripId()!=existingTripDetailsName.get().getTripId())){
            throw new TripAlreadyExistsException(TRIP_ALREADY_EXISTS);
        }
        tripDetails.setTripId(id);
        return tripRepo.save(tripDetails);
    }

    @Transactional
    @Override
    public boolean deleteTrip(int tripId) throws TripNotFoundException {
        // Delete trip by ID
        Optional<TripDetails> existingTripDetails = tripRepo.findById(tripId);
        if (existingTripDetails.isEmpty()) {
            throw new TripNotFoundException(TRIP_NOT_FOUND);
        }
        travellerRepo.deleteTravellersByTripId(tripId);
        tripRepo.deleteById(tripId);
        return true;
    }

    @Override
    public int findRemainingSeats(int tripId) throws TripNotFoundException {
        Optional<TripDetails> tripDetails = tripRepo.findById(tripId);
        if (tripDetails.isEmpty()) {
            throw new TripNotFoundException(TRIP_NOT_FOUND);
        }
        return tripDetails.get().getAvailableSeats();
    }

    @Override
    public List<TripDetails> getTripsSortedByPrice(String order) {
        // Get trips sorted by price
        List<TripDetails> tripDetails = null;
        if (order.equals("ascending")) {
            tripDetails = tripRepo.findTripByAcs();
        } else if (order.equals("descending")) {
            tripDetails = tripRepo.findTripByDsc();
        }
        return tripDetails;
    }

    @Override
    public List<TripDetails> getTripsByName(String tripName) {
        // Get trips by name
        return tripRepo.findByTripNames(tripName);
    }

}
