package com.examly.springapp.service; // Define the package name
 
import java.util.List; // Import necessary classes
import java.util.Optional; // Import Optional class

import org.springframework.security.core.userdetails.UserDetails; // Import UserDetails interface
import org.springframework.security.core.userdetails.UserDetailsService; // Import UserDetailsService interface
import org.springframework.security.core.userdetails.UsernameNotFoundException; // Import UsernameNotFoundException class
import org.springframework.stereotype.Service; // Import Service annotation

import com.examly.springapp.config.UserPrinciple; // Import UserPrinciple class
import com.examly.springapp.exceptions.UserNotFoundException;
import com.examly.springapp.model.User; // Import User model
import com.examly.springapp.repository.TravellerRepo;
import com.examly.springapp.repository.UserRepo; // Import User repository

import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
 
@Service // Mark this class as a service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService, UserDetailsService { // Implement UserService and UserDetailsService interfaces

    private final UserRepo userRepo; // Inject User repository

    private final TravellerRepo travellerRepo; // Inject Traveller repository

    private static final String USER_NOT_FOUND="User not found!";
 
    @Override
    public User updateUser(int userId, User user) throws UserNotFoundException {
        // Update user details by ID
        Optional<User> existingUser = userRepo.findById(userId);
        if (existingUser.isPresent()) {
            user.setUserId(userId);
            return userRepo.save(user);
        }
        throw new UserNotFoundException(USER_NOT_FOUND);
    }
 
    @Transactional
    @Override
    public void deleteUser(int userId) throws UserNotFoundException {
        // Delete user by ID
        Optional<User> existingUser = userRepo.findById(userId);
        if (existingUser.isEmpty()) {
            throw new UserNotFoundException(USER_NOT_FOUND);
        }
        travellerRepo.deleteTravellersByUserId(userId);
        userRepo.deleteById(userId);
    }
 
    @Override
    public User findUserById(int userId) throws UserNotFoundException {
        // Find user by ID
        Optional<User> existingUser = userRepo.findById(userId);
        if (existingUser.isEmpty()) {
            throw new UserNotFoundException(USER_NOT_FOUND);
        }
        return existingUser.get();
    }
 
    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        // Load user by username (email)
        Optional<User> user = userRepo.findByEmail(email);
        if (user.isEmpty()) {
            throw new UsernameNotFoundException(USER_NOT_FOUND);
        }
        return new UserPrinciple(user.get());
    }
 
    @Override
    public User getUserByEmail(String email) throws UserNotFoundException {
        // Get user by email
        Optional<User> user = userRepo.findByEmail(email);
        if (user.isEmpty()) {
            throw new UsernameNotFoundException(USER_NOT_FOUND);
        }
        return user.get();
    }
 
    @Override
    public List<User> getAllUsers() {
        // Get all users
        return userRepo.findAll();
    }
}