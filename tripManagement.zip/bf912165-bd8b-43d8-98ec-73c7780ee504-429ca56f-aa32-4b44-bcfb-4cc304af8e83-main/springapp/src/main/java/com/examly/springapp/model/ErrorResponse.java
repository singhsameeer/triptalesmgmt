package com.examly.springapp.model;

import lombok.Data;

@Data
public class ErrorResponse {

}
