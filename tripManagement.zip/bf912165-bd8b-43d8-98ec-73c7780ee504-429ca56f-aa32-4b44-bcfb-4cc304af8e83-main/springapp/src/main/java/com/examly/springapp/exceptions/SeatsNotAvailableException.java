package com.examly.springapp.exceptions;

public class SeatsNotAvailableException extends Exception{
    public SeatsNotAvailableException(String msg){
        super(msg);
    }
}
