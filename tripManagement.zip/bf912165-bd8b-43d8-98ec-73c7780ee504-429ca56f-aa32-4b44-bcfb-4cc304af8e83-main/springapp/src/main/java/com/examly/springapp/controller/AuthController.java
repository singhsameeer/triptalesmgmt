/*Define the package name, Import necessary classes, Import ResponseEntity class
Import CrossOrigin annotation,Import PostMapping annotation,Import RequestBody annotation
Import RequestMapping annotation,Import RestController annotation, Import UserNotFoundException class
Import LoginDTO class,Import UserDTO class, Import User model
Import UserService class,Import Valid annotation*/
package com.examly.springapp.controller; 

import org.springframework.http.ResponseEntity; 
import org.springframework.web.bind.annotation.PostMapping; 
import org.springframework.web.bind.annotation.RequestBody; 
import org.springframework.web.bind.annotation.RequestMapping; 
import org.springframework.web.bind.annotation.RestController;

import com.examly.springapp.dto.LoginDTO;
import com.examly.springapp.dto.UserDTO;
import com.examly.springapp.exceptions.UserAlreadyExistsException;
import com.examly.springapp.exceptions.UserNotFoundException;
import com.examly.springapp.model.User;
import com.examly.springapp.service.AuthService;


import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j; 
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;


/* Mark this class as a RestController, Enable CORS for all origins,Define the base URL for the API
Inject UserService,Handle user registration, create a new user, and return the response 
Handle user login, authenticate the user, and return the response*/

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/api") 
@Tag(name = "Auth Controller", description = "Controller for user authentication and registration")
public class AuthController {

    private final AuthService authService; 
     
    @PostMapping("/register")
    @Operation(summary = "Add user to the user repo.", description = "Registers a new user in the system", responses = {
        @ApiResponse(responseCode = "201", description = "User added successfully",
            content = @Content(mediaType = "application/json",
            schema = @Schema(implementation = User.class))),
        @ApiResponse(responseCode = "400", description = "Invalid input",
            content = @Content),
        @ApiResponse(responseCode = "500", description = "Internal server error",
            content = @Content)
    })
    public ResponseEntity<User> registerUser(@Valid @RequestBody User user) throws UserAlreadyExistsException {
        log.info("/api/register");
        return ResponseEntity.status(201).body(authService.createUser(user));
    }

    @PostMapping("/login")
    @Operation(summary = "User login", description = "Authenticates a user and returns user details if successful", responses = {
        @ApiResponse(responseCode = "200", description = "Login successful",
            content = @Content(mediaType = "application/json",
            schema = @Schema(implementation = UserDTO.class))),
        @ApiResponse(responseCode = "400", description = "Invalid input",
            content = @Content),
        @ApiResponse(responseCode = "401", description = "Unauthorized - Login failed",
            content = @Content),
        @ApiResponse(responseCode = "500", description = "Internal server error",
            content = @Content)
    })
    public ResponseEntity<Object> loginUser(@Valid @RequestBody LoginDTO user) throws UserNotFoundException {
       log.info("/api/login");
        UserDTO userDTO = authService.loginUser(user);
        if (userDTO != null) {
            return ResponseEntity.status(200).body(userDTO);
        }
        return ResponseEntity.status(500).body("Login failed");
    }
}
