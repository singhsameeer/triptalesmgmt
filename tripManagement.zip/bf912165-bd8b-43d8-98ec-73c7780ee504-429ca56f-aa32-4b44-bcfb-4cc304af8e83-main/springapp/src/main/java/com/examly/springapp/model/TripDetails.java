package com.examly.springapp.model; // Define the package name

import java.util.List; // Import necessary classes

import jakarta.persistence.Entity; // Import JPA annotations for entity mapping
import jakarta.persistence.GeneratedValue; // Import GeneratedValue annotation
import jakarta.persistence.GenerationType; // Import GenerationType enum
import jakarta.persistence.Id; // Import Id annotation
import jakarta.validation.constraints.Min; // Import Min validation annotation
import jakarta.validation.constraints.NotNull; // Import NotNull validation annotation
import lombok.Data; // Import Lombok's Data annotation

@Data // Generate getters, setters, equals, hash, and toString methods
@Entity // Mark this class as a JPA entity
public class TripDetails {
    @Id // Mark this field as the primary key
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Configure the primary key generation strategy
    private int tripId; // Define trip ID field
    private String tripName; // Define trip name field

    @NotNull(message = "Trip Duration cannot be null") // Ensure tripDuration is not null
    @Min(value = 1, message = "Trip Duration can not be less than 1") // Ensure tripDuration is not less than 1
    private int tripDuration; // Define trip duration field

    @NotNull(message = "Trip Price cannot be null") // Ensure tripPrice is not null
    @Min(value = 1000, message = "Trip Price can not be less than 1000") // Ensure tripPrice is not less than 1000
    private long tripPrice; // Define trip price field

    @NotNull(message = "Trip Start Location cannot be null") // Ensure tripStartLocation is not null
    private String tripStartLocation; // Define trip start location field

    @NotNull(message = "Trip Location cannot be null") // Ensure tripLocations is not null
    private List<String> tripLocations; // Define trip locations field

    @NotNull(message = "Trip Date cannot be null") // Ensure date is not null
    private String date; // Define date field

    @NotNull(message = "Trip Duration cannot be null") // Ensure totalSeats is not null
    @Min(value = 1, message = "Trip Duration can not be less than 1") // Ensure totalSeats is not less than 1
    private int totalSeats; // Define total seats field

    @NotNull(message = "Trip Duration cannot be null") // Ensure availableSeats is not null
    private int availableSeats; // Define available seats field

    @NotNull(message = "Points cannot be null") // Ensure points is not null
    @Min(value = 1, message = "Points can not be less than 1") // Ensure points is not less than 1
    private int points; // Define points field
}
