package com.examly.springapp.dto; // Define the package name

import jakarta.validation.constraints.Min; // Import necessary classes for validation
import jakarta.validation.constraints.NotNull; // Import NotNull validation annotation
import lombok.Data; // Import Lombok's Data annotation

@Data // Generate getters, setters, equals, hash, and toString methods
public class TravellerApplicationDTO {
   @NotNull(message = "UserId cannot be null") // Ensure userId is not null
   @Min(value = 1, message = "UserId can not be less than 1") // Ensure userId is not less than 1
   private int userId; // Define userId field

   @NotNull(message = "TripId cannot be null") // Ensure tripId is not null
   @Min(value = 1, message = "TripId can not be less than 1") // Ensure tripId is not less than 1
   private int tripId; // Define tripId field
}
