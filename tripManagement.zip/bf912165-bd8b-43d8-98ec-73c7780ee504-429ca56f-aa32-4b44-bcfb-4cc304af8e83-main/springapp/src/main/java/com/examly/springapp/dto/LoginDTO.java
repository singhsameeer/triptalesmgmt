package com.examly.springapp.dto; // Define the package name

import jakarta.validation.constraints.Email; // Import necessary classes for validation
import jakarta.validation.constraints.NotNull; // Import NotNull validation annotation
import jakarta.validation.constraints.Pattern;
import lombok.Data; // Import Lombok's Data annotation

@Data // Generate getters, setters, equals, hash, and toString methods
public class LoginDTO {
    @NotNull(message = "Email cannot be null") // Ensure email is not null
    @Email(message = "Email should be valid") // Ensure email is valid
    private String email; // Define email field

    @NotNull(message = "Password cannot be null") // Ensure password is not null
    @Pattern(regexp = "^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)(?=.*[@$!%*?&#])[A-Za-z\\d@$!%*?&#]{8,16}$", message = "Password must contain at least one uppercase letter, one lowercase letter, one number, one special character, and be at least 8 characters long") // Ensure password meets requirements
    private String password; // Define password field
}
