/*Define the package name,Import necessary classes,Import Value annotation,Import UserDetails interface,
Import Component annotation,Import Jwts class from io.jsonwebtoken,Import SignatureAlgorithm enum from io.jsonwebtoken
Import HttpServletRequest class*/
 
 
package com.examly.springapp.config;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
 
import org.springframework.beans.factory.annotation.Value;  
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;
 
import com.examly.springapp.model.User;
 
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import jakarta.servlet.http.HttpServletRequest;
 
 
/*Mark this class as a Spring component,Inject token duration from application properties,Inject secret key from application properties
 Create a JWT token with subject, issued date, expiration date, and signature
*/
@Component
public class JwtUtils {
    @Value("${token.duration}")
    long duration;
    @Value("${secret.key}")
    String secretKey;
 
    public String createToken(UserDetails details) {
       
        return Jwts.builder()
                .setSubject(details.getUsername())
                .setIssuedAt(new Date())
                .setExpiration(new Date(new Date().getTime() + duration))
                .signWith(SignatureAlgorithm.HS256, secretKey)
                .compact();
    }
 /*  Extract the username (subject) from the token ,Extract the expiration date from the token,Check if the token is expired
  Validate the token by checking if it's not expired,Extract the token from the Authorization header of the request,
  Remove "Bearer " prefix and return the token,Return null if the token is not present in the header
 */
 
    public String extractEmailFromToken(String token, String claimKey) {
       try{
            Claims claims = Jwts.parser()
            .setSigningKey(secretKey)
            .parseClaimsJws(token)
            .getBody();
            return claims != null ? claims.get(claimKey, String.class) : null;
       }
       catch(Exception e){return null;}
    }
 
    public Date extractExpiration(String token) {
        return Jwts.parser()
                .setSigningKey(secretKey)
                .parseClaimsJws(token)
                .getBody()
                .getExpiration();
    }
 
    public boolean isTokenExpired(String token) {
        return extractExpiration(token).before(new Date());
    }
 
    public boolean validateToken(String token) {
        return !isTokenExpired(token);
    }
 
    public String extractToken(HttpServletRequest request) {
        String header = request.getHeader("Authorization");
        if (header != null && header.startsWith("Bearer")) {
            return header.substring(7);
        }
        return null;
    }
 
    public String createToken(User user) {
        Map<String,Object>  map= new HashMap<>();
        map.put("subject", user.getUsername());
        map.put("role", user.getUserRole());
        map.put("email", user.getEmail());
 
          return Jwts.builder()
                    .setClaims(map)
                    .setIssuedAt(new Date())
                    .setExpiration(new Date(new Date().getTime() + duration))
                    .signWith(SignatureAlgorithm.HS256, secretKey)
                .compact();
    }
 
   
}