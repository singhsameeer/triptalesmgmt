package com.examly.springapp.model; // Define the package name

import jakarta.persistence.Column; // Import necessary classes for JPA entity mapping
import jakarta.persistence.Entity; // Import Entity annotation
import jakarta.persistence.GeneratedValue; // Import GeneratedValue annotation
import jakarta.persistence.GenerationType; // Import GenerationType enum
import jakarta.persistence.Id; // Import Id annotation
import jakarta.validation.constraints.Email; // Import Email validation annotation
import jakarta.validation.constraints.NotNull; // Import NotNull validation annotation
import jakarta.validation.constraints.Pattern; // Import Pattern validation annotation
import jakarta.validation.constraints.Size; // Import Size validation annotation
import lombok.Data; // Import Lombok's Data annotation

@Data // Generate getters, setters, equals, hash, and toString methods
@Entity // Mark this class as a JPA entity
public class User {
    @Id // Mark this field as the primary key
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Configure the primary key generation strategy
    private int userId; // Define user ID field

    @NotNull(message = "Email cannot be null") // Ensure email is not null
    @Email(message = "Email should be valid") // Ensure email is valid
    @Column(unique = true) // Ensure email is unique
    private String email; // Define email field

    @NotNull(message = "Password cannot be null") // Ensure password is not null
    @Size(min = 6, message = "Password should have at least 6 characters") // Ensure password has at least 6 characters
    private String password; // Define password field

    @NotNull(message = "Username cannot be null") // Ensure username is not null
    @Size(min = 4, message = "Username should have at least 4 characters") // Ensure username has at least 4 characters
    @Pattern(regexp = "^[a-z0-9]{4,10}$", message = "Username must contain only lowercase letters and numbers and be at least 4 characters long") // Ensure username meets requirements
    private String username; // Define username field


    @NotNull(message = "Mobile number cannot be null") // Ensure mobile number is not null
    @Size(min = 10, max = 10, message = "Mobile number must be 10 digits") // Ensure mobile number is exactly 10 digits
    @Pattern(regexp = "\\d{10}", message = "Mobile number must be 10 digits") // Ensure mobile number contains only digits
    private String mobileNumber; // Define mobile number field

    @NotNull(message = "User role cannot be null") // Ensure user role is not null
    @Pattern(regexp = "User|Admin", message = "User role must be either User or Admin") // Ensure user role matches pattern
    private String userRole; // Define user role field
}
