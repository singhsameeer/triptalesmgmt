package com.examly.springapp.exceptions;

public class TripAlreadyExistsException extends Exception {
    public TripAlreadyExistsException(String msg){
        super(msg);
    }
}
