import { Component, ElementRef, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-adminnav',
  templateUrl: './adminnav.component.html',
  styleUrls: ['./adminnav.component.css']
})
export class AdminnavComponent{

  // Access the navbarDropdown element in the template using ViewChild
  @ViewChild('navbarDropdown', { static: false }) navbarDropdown: ElementRef;

  // Authentication service instance
  auth:any=this.authService
  // Boolean flag to show or hide the logout confirmation popup
  showLogoutPopup:boolean=false

  // Constructor to inject AuthService and Router
  constructor(private readonly authService:AuthService,private readonly router:Router) { }


  // Function to toggle the dropdown menu
  toggleDropdown(event: Event) {
    event.preventDefault();
    if (this.navbarDropdown?.nativeElement) {
      // Access the next sibling element of the navbarDropdown (which is the dropdown menu)
      const dropdownMenu = this.navbarDropdown.nativeElement.nextElementSibling;
      // Toggle the 'show' class to open/close the dropdown menu
      if (dropdownMenu.classList.contains('show')) {
        dropdownMenu.classList.remove('show');
      } else {
        dropdownMenu.classList.add('show');
      }
    } else {
      console.error('NavbarDropdown element is not defined.');
    }
  }
  // Function to show the logout confirmation popup
  logout(){
    this.showLogoutPopup=true;
  }

  // Function to confirm logout and navigate to the home page
  confirmLogout(){
    // Call the logout method from AuthService
    this.authService.logout();
    // Wait for 1 second before navigating to the home page
    setTimeout(() => {
      this.router.navigate(['/']);
    }, 1000);
    // Hide the logout confirmation popup
    this.showLogoutPopup=false;
  }

  // Function to cancel the logout action
  cancelLogout(){
    this.showLogoutPopup=false;
  }

  onKeyDown(event: KeyboardEvent) {
    console.log('Key pressed:', event.key);
  }

  
}
