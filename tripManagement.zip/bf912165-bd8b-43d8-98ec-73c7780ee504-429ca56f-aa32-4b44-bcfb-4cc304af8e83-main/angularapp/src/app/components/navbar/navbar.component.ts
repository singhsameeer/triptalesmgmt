import { Component, ElementRef, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent{

  // Access the navbarDropdown element in the template using ViewChild
  @ViewChild('navbarDropdown', { static: false }) navbarDropdown: ElementRef;
  // Variable to store the user's role
  userRole:string = ''
  // Variable to store the user's email
  email:string = ''
  // Flag to show/hide the logout confirmation popup
  showLogoutPopup:boolean=false
  // Flag to show/hide the success message popup
  showSuccessPopup:boolean=false
  // Flag to show/hide the dropdown menu
  showDropdown:boolean=false
  // Instance of the authentication service
  auth=this.authService

  // Constructor to inject AuthService and Router
  constructor(private readonly authService: AuthService, private readonly router: Router) {}

  // Function to show the logout confirmation popup
  logout(){
    this.showLogoutPopup=true;
  }

  // Function to cancel the logout action and hide the confirmation popup
  cancelLogout(){
    this.showLogoutPopup=false
  }

  // Function to confirm the logout action, log the user out, and show the success popup
  confirmLogout(){
    this.authService.logout();
    this.showLogoutPopup=false;
    this.showSuccessPopup=true
    // Navigate to the login page after a short delay
    setTimeout(() => {
      this.router.navigate(['/login']);
      this.showSuccessPopup = false;
    }, 1000);
  }

  // Function to close the success message popup
  closeSuccessPopup(){
    this.showSuccessPopup=false
    this.router.navigate(['/'])
  }


}
