import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import {  NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { TripDetails } from 'src/app/models/trip-details.model';
import { TripService } from 'src/app/services/trip.service';


@Component({
  selector: 'app-edit-trip',
  templateUrl: './edittrip.component.html',
  styleUrls: ['./edittrip.component.css']
})
export class EdittripComponent implements OnInit {
  
  // Array of available locations for trips
  availableLocations: string[] = ["Jaipur", "Jodhpur", "Udaipur",
  "Dehradun", "Rishikesh", "Manali", "Leh",
  "Kochi", "Alleppey", "Munnar",
  "Panaji", "Calangute", "Anjuna",
  "Gangtok", "Lachung", "Pelling",
  "Jaisalmer", "Bikaner", "Pushkar",
  "Kolkata", "Shantiniketan", "Sundarbans",
  "Shimla", "Kullu", "Manali",
  "Varanasi", "Sarnath", "Allahabad",
  "Chennai", "Pondicherry", "Madurai", "Kanyakumari",
  "Goa", "Agra", "Delhi", "Mumbai", "Bengaluru", "Hyderabad",
  "Darjeeling", "Ooty", "Amritsar", "Puducherry"];
  // Array to store selected locations for the trip
  selectedLocations: string[] = [];
  // Variable to hold new location input
  newLocation: string = '';
  // Flags to show/hide success and failure modals
  showSuccessModal: boolean = false;
  showFailureModal: boolean = false;
  errormessage:string=''
  minDate: string='';
  // Trip object to hold trip details
  trip: TripDetails = {
    tripId: 0,
    tripName: '',
    tripDuration: 0,
    tripPrice: 0,
    tripStartLocation: '',
    tripLocations: [],
    date: '',
    totalSeats: 0,
    availableSeats: 0,
    points: 0
  };

  // Constructor to inject TripService, ActivatedRoute, and Router
  constructor(
    private readonly tripService: TripService,
    private readonly route: ActivatedRoute,
    private readonly router: Router
  ) { }

  // Lifecycle hook that is called after Angular has initialized all data-bound properties
  ngOnInit(): void {
    // Retrieve the trip ID from route parameters
    const tripId = +this.route.snapshot.paramMap.get('id')!;
    if (tripId) {
      // Fetch trip details by trip ID
      this.tripService.findTripById(tripId).subscribe((data: TripDetails) => {
          this.trip = data;
          this.selectedLocations = data.tripLocations;
          this.trip.date = this.formatDate(data.date);
        },
        (error:HttpErrorResponse) => {
          this.errormessage=error.error
          console.error('Error fetching trip details:', error);
        }
      );
    } else {
      console.error('No tripId found in route parameters');
    }

    // Get today's date in YYYY-MM-DD format
    const today = new Date();
    const day = String(today.getDate()).padStart(2, '0');
    const month = String(today.getMonth() + 1).padStart(2, '0'); // Months are 0-based
    const year = today.getFullYear();
    this.minDate = `${year}-${month}-${day}`;
  }

  // Function to format date as YYYY-MM-DD
  formatDate(date: string | Date): string {
    const d = new Date(date);
    if (isNaN(d.getTime())) {
      return '';
    }
    const month = ('0' + (d.getMonth() + 1)).slice(-2);
    const day = ('0' + d.getDate()).slice(-2);
    const year = d.getFullYear();
    return `${year}-${month}-${day}`;
  }

  // Function to add a location to the selected locations array
  addLocation(): void {
    if (this.newLocation.trim() && !this.selectedLocations.includes(this.newLocation)) {
      this.selectedLocations.push(this.newLocation);
      this.newLocation = '';
    }
  }

  // Function to remove a location from the selected locations array
  removeLocation(index: number): void {
    this.selectedLocations.splice(index, 1);
  }
 
  // Function to update the trip details
  updateTrip(tripForm: NgForm): void {
    if (tripForm.valid) {
      const updatedTrip: TripDetails = {
        ...this.trip,
        tripName: tripForm.value.tripName,
        tripDuration: tripForm.value.tripDuration,
        tripPrice: tripForm.value.tripPrice,
        tripStartLocation: tripForm.value.tripStartLocation,
        tripLocations: this.selectedLocations,
        date: tripForm.value.date,
        totalSeats: tripForm.value.totalSeats,
        availableSeats: tripForm.value.availableSeats,
        points: tripForm.value.points
      };
      if (tripForm.valid) {
        if (this.trip.availableSeats > this.trip.totalSeats) {
          this.errormessage = 'Available seats cannot be more than total seats.';
          this.showFailureModal = true;
          return;
        }
      }
      // Call the updateTrip method from TripService to update the trip
      this.tripService.updateTrip(this.trip.tripId, updatedTrip).subscribe(() => {
          this.showSuccessModal = true;
          setTimeout(() => {
            this.router.navigate(['/adminview-trip']);
          }, 3000);
        },(error:HttpErrorResponse) => {
          this.errormessage=error.error
          this.showFailureModal = true;
        });
    }
  }

  // Function to close success and failure modals
  closeModals(): void {
    this.showSuccessModal = false;
    this.showFailureModal = false;
  }

  // Function to navigate to the admin view trips page after successful update
  navigateToTrips(): void {
    this.showSuccessModal = false;
    this.router.navigate(['/adminview-trip']);
  }

  // TrackBy function for ngFor to optimize rendering
  trackByFn(index: number, item: any): number {
    return index; // or item.id
  }

  preventInvalidInput(event: KeyboardEvent) {
    if (['e', 'E', '+', '-'].includes(event.key)) {
      event.preventDefault();
    }
  }
}
