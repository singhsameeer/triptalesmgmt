import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminTravellerApplicationsComponent } from './admin-traveller-applications.component';

describe('AdminTravellerApplicationsComponent', () => {
  let component: AdminTravellerApplicationsComponent;
  let fixture: ComponentFixture<AdminTravellerApplicationsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminTravellerApplicationsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminTravellerApplicationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
