import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { User } from 'src/app/models/user.model';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  // Form group to manage the registration form
  registrationForm: FormGroup;
  // Flag to show/hide the success message
  successMessage: boolean = false;
  // Variable to store error messages
  errorMessage: string = '';
  // User object to hold registration data
  user: User = {
    email: '',
    password: '',
    username: '',
    mobileNumber: '',
    userRole: ''
  };

  // Constructor to inject FormBuilder, AuthService, and Router
  constructor(
    private readonly formBuilder: FormBuilder,
    private readonly authService: AuthService,
    private readonly router: Router
  ) { }

  // Lifecycle hook that is called after Angular has initialized all data-bound properties
  ngOnInit(): void {
    // Initialize the registration form with form controls and validators
    this.registrationForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [
        Validators.required,
        Validators.minLength(8),
        Validators.pattern('^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[!@#$%^&*])[a-zA-Z\\d!@#$%^&*]{8,}$')
      ]],
      username: ['', [
        Validators.required,
        Validators.minLength(3),
        Validators.pattern('^[a-z0-9]+$')
      ]],
      confirmPassword: ['', Validators.required],
      mobileNumber: ['', [Validators.required, Validators.pattern(/^\d{10}$/)]],
      userRole: ['', Validators.required]
    }, {validators: this.passwordMismatchValidator});
  }

  // Custom validator to check if password and confirm password match
  passwordMismatchValidator(signupForm:FormGroup):void{
    const password=signupForm.get('password')
    const confirmPassword=signupForm.get('confirmPassword')
    if(password.value!==confirmPassword.value){
      confirmPassword.setErrors({mismatch:true})
    }
  }

  // Function to register a new user
  register(){
    if (this.registrationForm.valid) {
      this.user = {
        email: this.registrationForm.get('email').value,
        password: this.registrationForm.get('password').value,
        username: this.registrationForm.get('username').value,
        mobileNumber: this.registrationForm.get('mobileNumber').value,
        userRole: this.registrationForm.get('userRole').value
      };
      // Call the registerUser method from AuthService to register the user
      console.log(this.user)
      this.authService.registerUser(this.user).subscribe(()=>{
        console.log(this.user);
        this.successMessage = true;
        this.errorMessage = '';
        // Redirect to the login page after a short delay
        setTimeout(() => {
          this.router.navigate(['/login']);
        }, 2000);
      }, (error: HttpErrorResponse) => {
        console.log("error")
        this.errorMessage = error.error;
      });
      // Reset the registration form
      this.registrationForm.reset();
    }
  }

  // Getter for form controls
  get f(){
    return this.registrationForm.controls;
  }
}
