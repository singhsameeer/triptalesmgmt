import { Component } from '@angular/core';


@Component({
  selector: 'app-requested-trip',
  templateUrl: './requested-trip.component.html',
  styleUrls: ['./requested-trip.component.css']
})
export class RequestedTripComponent{

  constructor() { }
}