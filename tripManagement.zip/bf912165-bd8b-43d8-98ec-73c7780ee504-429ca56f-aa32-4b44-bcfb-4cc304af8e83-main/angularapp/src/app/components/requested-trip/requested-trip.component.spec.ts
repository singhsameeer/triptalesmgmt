import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RequestedTripComponent } from './requested-trip.component';

describe('RequestedTripComponent', () => {
  let component: RequestedTripComponent;
  let fixture: ComponentFixture<RequestedTripComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RequestedTripComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RequestedTripComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
