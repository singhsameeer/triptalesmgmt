import { Component, OnInit } from '@angular/core';
import { Loyalty } from 'src/app/models/loyalty.model';
import { User } from 'src/app/models/user.model';
import { AuthService } from 'src/app/services/auth.service';
import { LoyaltyService } from 'src/app/services/loyalty.service';

@Component({
  selector: 'app-claim-loyalty',
  templateUrl: './claim-loyalty.component.html',
  styleUrls: ['./claim-loyalty.component.css']
})
export class ClaimLoyaltyComponent implements OnInit {

  useremail: string = '';
  success: boolean = false;
  showModal: boolean = false;

  user: User = {
    userId: 0,
    email: '',
    password: '',
    username: '',
    mobileNumber: '',
    userRole: ''
  }

  loyalty:Loyalty={
    loyaltyPoints: 100,
  }
  constructor(private readonly authService:AuthService,private readonly loyaltyService:LoyaltyService) { }

  ngOnInit(): void {
    this.useremail = this.authService.getUseremail();
    this.authService.getUserByEmail(this.useremail).subscribe((res) => {
        this.user = res;
        this.getLoyalty();
      },
      (error) => {
        console.error('Error fetching user by email:', error);
      }
    );
  }

  getLoyalty(){
    this.loyaltyService.getLoyaltyPointsByUserId(this.user.userId).subscribe((res)=>{
      this.loyalty=res
    })
  }

  claimLoyalty() {
    if (this.loyalty == null) {
      this.loyalty = {
        loyaltyPoints: 100,
      }
      this.loyaltyService.addLoyalty(this.user.userId, this.loyalty).subscribe((res) => {
          this.success = true;
          this.showModal = true;
          this.ngOnInit();
        },(err) => {
          this.success = false;
          this.showModal = true;
        }
      );
    }
  }

  closeModal() {
    this.showModal = false;
  }
}
