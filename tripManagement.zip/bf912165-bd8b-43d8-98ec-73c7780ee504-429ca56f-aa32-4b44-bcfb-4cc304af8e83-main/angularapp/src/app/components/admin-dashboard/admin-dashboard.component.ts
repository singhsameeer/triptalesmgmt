import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/models/user.model';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.css']
})
export class AdminDashboardComponent implements OnInit {

  users:User[]=[]
  adminList:User[]=[]
  userList:User[]=[]

  showConfirmModal:boolean = false;
  showStatusModal:boolean = false;
  statusMessage: string='';
  userIdToDelete: number=0;

  constructor(private authService:AuthService) { }

  ngOnInit(): void {
    this.getAllUsers()
  }

  getAllUsers(){
    this.authService.getAllUsers().subscribe((res)=>{
      this.users=res
      this.adminList=this.users.filter(user=>user.userRole=='Admin');
      this.userList=this.users.filter(user=>user.userRole=='User');
    },(error)=>{
      console.log("error getting users")
    })
  }

  confirmDelete(id: number) {
    this.userIdToDelete = id;
    this.showConfirmModal = true;
  }

  closeConfirmModal() {
    this.showConfirmModal = false;
  }

  closeStatusModal() {
    this.showStatusModal = false;
    this.getAllUsers();
  }

  deleteConfirmedUser() {
    this.authService.deleteUser(this.userIdToDelete).subscribe(() => {
      this.statusMessage = "User deleted successfully!";
      this.showConfirmModal = false;
      this.showStatusModal = true;
    }, (error) => {
      this.statusMessage = "Failed to delete user!";
      this.showConfirmModal = false;
      this.showStatusModal = true;
    });
  }

}
