import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from '../models/user.model';
import { UserToken } from '../models/userToken.model';
import { JwtService } from './jwt.service';
import { API_END_POINTS } from '../app.constant';
 
@Injectable({
  providedIn: 'root'
})
export class AuthService {
 
  // Constructor to inject HttpClient service
  constructor(private readonly  http:HttpClient, private readonly jwtService:JwtService) {
  }
 
  // Method to check if the current user has 'Admin' role
  isAdmin():boolean{
    const token:string = localStorage.getItem('token');
    const role:string = this.jwtService.getClaim(token, 'role');
    return role == 'Admin';  // Return true if user role is 'Admin', else false
  }
 
  // Method to check if the current user has 'User' role
  isUser():boolean{
    const token:string = localStorage.getItem('token');
    const role:string = this.jwtService.getClaim(token, 'role');
    return role === 'User';  // Return true if user role is 'User', else false
  }
 
  // Method to get the user's email from local storage
  getUseremail():string{
    const token:string = localStorage.getItem('token');
    const email:string = this.jwtService.getClaim(token, 'email');
    return email;
  }
 
  // Method to get the user's role from local storage
  getUserrole():string{
    const token:string = localStorage.getItem('token');
    const role:string = this.jwtService.getClaim(token, 'role');
    return role;
  }
 
  // Method to log in the user by sending a POST request with user data and receiving a UserToken
  login(user:User):Observable<UserToken>{
    return this.http.post<UserToken>(`${API_END_POINTS.AUTH_URL}/login`, user);  // Send POST request to login endpoint
  }
 
  // Method to log out the user by removing user-related data from local storage
  logout(){
    localStorage.removeItem('token');  // Remove user token from local storage
  }
 
  // Method to check if a user is logged in by verifying the presence of user email in local storage
  isLoggedIn():boolean{
    const token:string = localStorage.getItem('token');  // Retrieve user email from local storage
    return !!token; // Return true if user email exists, else false
  }
 
  // Method to get user details by user ID by sending a GET request
  getUserbyId(userId:number):Observable<User>{
    return this.http.get<User>(`${API_END_POINTS.AUTH_URL}/user/${userId}`);  // Send GET request to user endpoint with userId
  }
 
  // Method to register a new user by sending a POST request with user data
  registerUser(user:User):Observable<User>{
    return this.http.post<User>(`${API_END_POINTS.AUTH_URL}/register`, user);  // Send POST request to register endpoint
  }
 
  // Method to get user details by user email by sending a GET request
  getUserByEmail(email:string):Observable<User>{
    return this.http.get<User>(`${API_END_POINTS.AUTH_URL}/user/userEmail/${email}`);  // Send GET request to user endpoint with email
  }

  getAllUsers():Observable<User[]>{
    return this.http.get<User[]>(`${API_END_POINTS.AUTH_URL}/user`);
  }

  deleteUser(userId:number):Observable<any>{
    return this.http.delete<any>(`${API_END_POINTS.AUTH_URL}/user/deleteUser/${userId}`); 
  }
 
}