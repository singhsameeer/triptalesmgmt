import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { TravellerService } from './traveller.service';

describe('TravellerService', () => {
  let service: TravellerService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
    });
    service = TestBed.inject(TravellerService);
  });

  fit('Frontend_should_create_traveller_service', () => {
    expect(service).toBeTruthy();
  });
});

