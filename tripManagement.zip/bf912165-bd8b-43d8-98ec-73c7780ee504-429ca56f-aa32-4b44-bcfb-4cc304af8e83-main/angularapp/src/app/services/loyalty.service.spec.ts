import { TestBed } from '@angular/core/testing';

import { LoyaltyService } from './loyalty.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('LoyaltyService', () => {
  let service: LoyaltyService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
    });
    service = TestBed.inject(LoyaltyService);
  });

  fit('Frontend_should_create_loyalty_service', () => {
    expect(service).toBeTruthy();
  });
});
