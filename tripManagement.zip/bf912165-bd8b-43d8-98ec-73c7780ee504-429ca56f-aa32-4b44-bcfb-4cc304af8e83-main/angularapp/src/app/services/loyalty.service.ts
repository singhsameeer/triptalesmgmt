import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Loyalty } from '../models/loyalty.model';
import { API_END_POINTS } from '../app.constant';

@Injectable({
  providedIn: 'root'
})
export class LoyaltyService {

  // Constructor to inject HttpClient service
  constructor(private readonly http:HttpClient) { }

  // Method to get loyalty points by user ID
  getLoyaltyPointsByUserId(userId:number):Observable<Loyalty>{
    return this.http.get<Loyalty>(`${API_END_POINTS.LOYALTY_URL}/user/${userId}`);  // Send GET request to loyalty endpoint with userId
  }

  // Method to add loyalty points for a specific user by user ID
  addLoyalty(userId:number, loyalty:Loyalty){
    return this.http.post<Loyalty>(`${API_END_POINTS.LOYALTY_URL}?userId=${userId}`, loyalty);  // Send POST request to add loyalty endpoint with userId
  }

  // Method to update loyalty points for a specific user by user ID
  updateLoyalty(userId:number, loyalty:Loyalty):Observable<Loyalty>{
    return this.http.put<Loyalty>(`${API_END_POINTS.LOYALTY_URL}/update/${userId}`, loyalty);  // Send PUT request to update loyalty endpoint with userId
  }
  
}
