import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { TripDetails } from '../models/trip-details.model';
import { API_END_POINTS } from '../app.constant';

@Injectable({
  providedIn: 'root'
})
export class TripService {

  // Constructor to inject HttpClient service
  constructor(private readonly http:HttpClient) { }

  // Method to add a new trip by sending a POST request with trip details
  addTrip(trip: TripDetails): Observable<TripDetails> {
    return this.http.post<TripDetails>(API_END_POINTS.TRIP_URL, trip);  // Send POST request to trip endpoint with trip details
  }

  // Method to find a trip by its ID
  findTripById(id: number): Observable<TripDetails> {
    return this.http.get<TripDetails>(`${API_END_POINTS.TRIP_URL}/get`, { params: { tripId: id.toString() } });  // Send GET request to trip endpoint with trip ID
  }

  // Method to get all trip details
  getAllTripDetails(): Observable<TripDetails[]> {
    return this.http.get<TripDetails[]>(`${API_END_POINTS.TRIP_URL}/getall`);  // Send GET request to get all trip details
  }

  // Method to update trip details by trip ID
  updateTrip(id: number, tripDetails: TripDetails): Observable<TripDetails> {
    return this.http.put<TripDetails>(`${API_END_POINTS.TRIP_URL}/update/${id}`, tripDetails);  // Send PUT request to update trip details endpoint with trip ID
  }

  // Method to get available seats for a trip by trip ID
  getAvailableSeats(id: number): Observable<string> {
    return this.http.get<string>(`${API_END_POINTS.TRIP_URL}/get/available/${id}`);  // Send GET request to get available seats endpoint with trip ID
  }

  // Method to delete a trip by trip ID
  deleteTrip(id: number): Observable<void> {
    return this.http.delete<void>(`${API_END_POINTS.TRIP_URL}/delete`, { params: { tripId: id.toString() } });  // Send DELETE request to delete trip endpoint with trip ID
  }

  // Method to search trips by name
  searchTripsByName(tripName: string): Observable<TripDetails[]> {
    return this.http.get<TripDetails[]>(`${API_END_POINTS.TRIP_URL}/searchByName`, { params: { tripName } });  // Send GET request to search trips by name endpoint with trip name
  }

  // Method to get trips sorted by price in a specified order
  getTripsSortedByPrice(order: string): Observable<TripDetails[]> {
    return this.http.get<TripDetails[]>(`${API_END_POINTS.TRIP_URL}/sortedByPrice`, { params: { order } });  // Send GET request to get trips sorted by price endpoint with order parameter
  }

}
