import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { TravellerApplication } from '../models/traveller-application.model';
import { Observable } from 'rxjs';
import { TripDetails } from '../models/trip-details.model';
import { API_END_POINTS } from '../app.constant';

@Injectable({
  providedIn: 'root'
})
export class TravellerService {

  constructor(private readonly  http:HttpClient) { }

  // Method to add a traveller application by sending a POST request with application data
  addTravellerApplication(travellerApplication:TravellerApplication):Observable<TravellerApplication>{
    return this.http.post<TravellerApplication>(API_END_POINTS.TRAVELLER_URL, travellerApplication);  // Send POST request to traveller endpoint
  }
  
  // Method to find a traveller application by its ID
  findTravellerApplicationById(id:number):Observable<TravellerApplication>{
    return this.http.get<TravellerApplication>(`${API_END_POINTS.TRAVELLER_URL}/gettraveller/${id}`);  // Send GET request to traveller endpoint with application ID
  }

  // Method to find trip details by user ID
  findTripDetailsByUserId(userId:number):Observable<TravellerApplication[]>{
    return this.http.get<TravellerApplication[]>(`${API_END_POINTS.TRAVELLER_URL}/get/userId/${userId}`);  // Send GET request to traveller endpoint with user ID
  }
  
  findTravellerApplicationsByUserId(userId:number):Observable<TravellerApplication[]>{
    return this.http.get<TravellerApplication[]>(`${API_END_POINTS.TRAVELLER_URL}/get/${userId}`)
  }

  // Method to update trip details by application ID
  updateTripDetails(id:number, tripDetails:TripDetails):Observable<TripDetails>{
    return this.http.patch<TripDetails>(`${API_END_POINTS.TRAVELLER_URL}/update/${id}`, tripDetails);  // Send PATCH request to update trip details endpoint with application ID
  }

  // Method to get all traveller applications
  getAllTravellerApplication():Observable<TravellerApplication[]>{
    return this.http.get<TravellerApplication[]>(`${API_END_POINTS.TRAVELLER_URL}/getall`);  // Send GET request to get all traveller applications
  }

  // Method to filter traveller applications by status
  filterTravellerApplicationByStatus(status: string): Observable<TravellerApplication[]> {
    return this.http.get<TravellerApplication[]>(`${API_END_POINTS.TRAVELLER_URL}/filterByStatus?paymentStatus=${status}`);  // Send GET request to filter traveller applications by status
  }

  
  // Method to update payment status by application ID
  updatePaymentStatus(id:number,paymentStatus:string):Observable<TravellerApplication>{
    return this.http.put<TravellerApplication>(`${API_END_POINTS.TRAVELLER_URL}/${id}/status/${paymentStatus}`,null)
  }

  // Method to get the trip price by traveller application ID
  getTripPriceByTravellerApplicationId(travellerApplicationId:number):Observable<number>{
    return this.http.get<number>(`${API_END_POINTS.TRAVELLER_URL}/${travellerApplicationId}/price`);  // Send GET request to get trip price endpoint with application ID
  }

  // Method to update loyalty points and status by traveller application ID and user ID
  updateLoyaltyAndStatus(travellerApplicationId:number, userId:number,seat:number):Observable<any>{
    return this.http.put(`${API_END_POINTS.TRAVELLER_URL}/${travellerApplicationId}/updateLoyalty/${userId}/seats/${seat}`,{});  // Send GET request to update loyalty and status endpoint with application ID and user ID
  }

}
