import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Feedback } from '../models/feedback.model';
import { API_END_POINTS } from '../app.constant';

@Injectable({
  providedIn: 'root'
})
export class FeedbackService {

  // Constructor to inject HttpClient service
  constructor(private readonly  http:HttpClient) { }

  // Method to send feedback by making a POST request with feedback data
  sendFeedback(feedback:Feedback):Observable<Feedback>{
    return this.http.post<Feedback>(API_END_POINTS.FEEDBACK_URL, feedback);  // Send POST request to feedback endpoint
  }

  // Method to get all feedbacks given by a specific user by user ID
  getAllFeedbacksByUserId(userId:number):Observable<Feedback[]>{
    return this.http.get<Feedback[]>(`${API_END_POINTS.FEEDBACK_URL}/user/${userId}`);  // Send GET request to feedback endpoint with userId
  }

  // Method to delete a specific feedback by feedback ID
  deleteFeedback(feedbackId:number):Observable<Feedback>{
    return this.http.delete<Feedback>(`${API_END_POINTS.FEEDBACK_URL}/${feedbackId}`);  // Send DELETE request to feedback endpoint with feedbackId
  }

  // Method to get all feedbacks
  getFeedbacks():Observable<Feedback[]>{
    return this.http.get<Feedback[]>(API_END_POINTS.FEEDBACK_URL);  // Send GET request to feedback endpoint
  }
  
}
