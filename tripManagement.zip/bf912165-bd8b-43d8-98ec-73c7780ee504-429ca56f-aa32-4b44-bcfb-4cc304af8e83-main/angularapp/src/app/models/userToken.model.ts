// Interface definition for UserToken
export interface UserToken {
    // Property to store the authentication token
    token: string;
}
