import { Loyalty } from "./loyalty.model"; 

describe('Loyalty Model', () => {

  fit('Frontend_Loyalty_model_should_create_an_instance', () => {
    // Create a sample Loyalty object
    const loyalty: Loyalty = {
      id: 1,                        
      loyaltyPoints:100,    
      loyaltyLevel: 2,                   
      benefits: ["Zero Cancellation Fee"]
    };

    expect(loyalty.loyaltyPoints).toBe(100);
    expect(loyalty.loyaltyLevel).toBe(2);
  });

});

  