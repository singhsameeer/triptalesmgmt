// Login class definition
export class Login {
    // Property to store the user's email
    email: string;
    // Property to store the user's password
    password: string;
}
