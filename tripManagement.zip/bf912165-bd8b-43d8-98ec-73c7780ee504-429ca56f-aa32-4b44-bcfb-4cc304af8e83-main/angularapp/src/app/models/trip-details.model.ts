import { TravellerApplication } from "./traveller-application.model"

// Interface definition for TripDetails
export interface TripDetails {
    // Optional property for trip ID
    tripId?: number;
    // Property for trip name
    tripName: string;
    // Property for trip duration (in days)
    tripDuration: number;
    // Property for trip price
    tripPrice: number;
    // Property for trip start location
    tripStartLocation: string;
    // Property for trip locations (array of strings)
    tripLocations: string[];
    // Property for trip date (in string format)
    date: string;
    // Property for total seats available in the trip
    totalSeats: number;
    // Property for available seats in the trip
    availableSeats: number;
    // Property for loyalty points earned from the trip
    points: number;
    // Optional property for traveller applications (array of TravellerApplication objects)
    travellerApplications?: TravellerApplication[];
}
