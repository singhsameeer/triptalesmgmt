import { TripDetails } from './trip-details.model';

describe('TripDetails Model', () => {

  fit('Frontend_TripDetails_model_should_create_an_instance', () => {
    // Create a sample TripDetails object
    const tripDetails: TripDetails = {
      tripId: 1,                        // Primary Key
      tripName: 'Mountain Adventure',    // Name of the trip
      tripDuration: 5,                   // Duration of the trip in days
      tripPrice: 1500,                   // Price of the trip
      tripStartLocation: 'City Center',  // Starting location of the trip
      tripLocations: ['Mountain A', 'Mountain B'], // List of locations
      date: '2024-07-15',                // Date of the trip
      totalSeats: 30,                    // Total number of seats
      availableSeats: 10,
      points:100,                // Available seats
      travellerApplications: []           // Array of traveller applications
    };

    expect(tripDetails.tripDuration).toBe(5);
    expect(tripDetails.tripPrice).toBe(1500);
  });

});
