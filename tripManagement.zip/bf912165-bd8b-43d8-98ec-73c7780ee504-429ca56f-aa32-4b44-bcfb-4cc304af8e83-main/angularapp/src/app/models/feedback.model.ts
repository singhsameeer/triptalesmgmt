import { User } from "./user.model"

// Feedback class definition
export class Feedback {
    // Optional property for feedback ID
    feedbackId?: number;
    // Optional property for user ID
    userId?: number;
    // Optional property for user details (reference to User model)
    user?: User;
    // Property for feedback text
    feedbackText: string;
    // Optional property for feedback date
    date?: Date;
}
